#pragma once
#include <cmath>
#include <algorithm>
#include <cstring>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

namespace ps3100 {

struct SVFBandpass {
    double low=0,band=0,high=0;
    void reset(){low=band=high=0;}
    double process(double in,double freq,double q,double sr){
        double f=2*std::sin(M_PI*std::min(freq,sr*0.45)/sr),qi=1/std::max(q,0.5);
        for(int i=0;i<2;++i){low+=f*band;high=in-low-qi*band;band+=f*high;}return band;}
};

struct Vactrol {
    double state=0,ac=0,rc=0;
    void prepare(double sr){ac=1-std::exp(-1/(0.005*sr));rc=1-std::exp(-1/(0.05*sr));state=0;}
    double process(double t){state+=((t>state)?ac:rc)*(t-state);return state;}
};

inline double softClip(double x){double xg=x*1.8;return std::tanh(xg*0.9)+0.05*std::tanh(xg*3.0);}

struct DCBlocker {
    double x1=0,y1=0;
    double process(double x){y1=x-x1+0.9995*y1;x1=x;return y1;}
    void reset(){x1=y1=0;}
};

struct Smoother {
    double target=0,current=0,coeff=0;
    void prepare(double sr,double ms=20){coeff=1-std::exp(-1/(ms*0.001*sr));current=target;}
    void setTarget(double t){target=t;}
    double next(){current+=coeff*(target-current);return current;}
};

inline double bitCrush(double x,double amount){
    if(amount<0.001)return x;
    double bits=16-amount*12;double levels=std::pow(2.0,bits);
    return std::round(x*levels)/levels;
}

// ═══════════ MULTIBAND DELAY (8 bands) ═══════════════════════

struct DelayLine {
    static constexpr int MAX_LEN=48000;
    double buf[MAX_LEN]{};int wp=0;
    void prepare(){std::memset(buf,0,sizeof(buf));wp=0;}
    void write(double v){buf[wp]=v;wp=(wp+1)%MAX_LEN;}
    double read(double ds)const{ds=std::min(ds,(double)(MAX_LEN-2));int d=(int)ds;double fr=ds-d;int i0=(wp-d-1+MAX_LEN)%MAX_LEN,i1=(i0-1+MAX_LEN)%MAX_LEN;return buf[i0]*(1-fr)+buf[i1]*fr;}
};

struct MultibandDelay {
    static constexpr int NUM_BANDS=8;
    double centerFreqs[NUM_BANDS]={100,200,400,800,1500,3000,6000,12000};
    SVFBandpass filters[NUM_BANDS];DelayLine delays[NUM_BANDS];
    Smoother delaySm[NUM_BANDS],fbSm[NUM_BANDS],mixSm;
    double sr=44100;
    void prepare(double s){sr=s;mixSm.prepare(sr,20);for(int i=0;i<NUM_BANDS;++i){filters[i].reset();delays[i].prepare();delaySm[i].prepare(sr,30);fbSm[i].prepare(sr,20);}}
    double process(double input){double wet=0,mix=mixSm.next();if(mix<0.001)return input;for(int i=0;i<NUM_BANDS;++i){double bp=filters[i].process(input,centerFreqs[i],4.0,sr);double dt=delaySm[i].next();double fb=fbSm[i].next();double delayed=delays[i].read(dt);delays[i].write(bp+delayed*fb);wet+=delayed;}wet*=0.25;return input*(1-mix)+wet*mix;}
};

// ═══════════ FREQUENCY SHIFTER ═══════════════════════════════

struct FreqShifter {
    double phase=0,lpState=0;Smoother shiftSm;double sr=44100;
    void prepare(double s){sr=s;phase=0;lpState=0;shiftSm.prepare(sr,30);}
    double process(double input){double hz=shiftSm.next();if(std::abs(hz)<0.1)return input;phase+=hz/sr;if(phase>1)phase-=1;if(phase<-1)phase+=1;double mod=std::sin(2*M_PI*phase);double shifted=input*mod;lpState+=0.15*(shifted-lpState);return lpState*2.0;}
};

// ═══════════ 8-BAND SELF-MODULATING VOCODER ══════════════════
// Enhanced: slightly lower Q on low bands for fuller bass,
// slightly higher gain multiplier, longer envelope release
// for more sustained watery resonance.

struct EnvelopeFollower {
    double state=0,ac=0,rc=0;
    void prepare(double sr){
        ac=1-std::exp(-1/(0.002*sr));
        rc=1-std::exp(-1/(0.025*sr)); // longer release (was 0.015) = more sustain
        state=0;
    }
    double process(double x){double a=std::abs(x);state+=((a>state)?ac:rc)*(a-state);return state;}
};

struct Vocoder {
    static constexpr int NUM_BANDS=8;
    double freqs[NUM_BANDS]={200,400,800,1200,1600,2400,3200,4800};
    // Slightly lower Q on low bands for fuller body
    double bandQ[NUM_BANDS]={6,6,7,8,8,8,8,8};

    SVFBandpass carrierFilters[NUM_BANDS],modFilters[NUM_BANDS];
    EnvelopeFollower envFollowers[NUM_BANDS];
    Smoother bandGainSm[NUM_BANDS],mixSm;
    double sr=44100;

    void prepare(double s){sr=s;mixSm.prepare(sr,20);for(int i=0;i<NUM_BANDS;++i){carrierFilters[i].reset();modFilters[i].reset();envFollowers[i].prepare(sr);bandGainSm[i].prepare(sr,20);}}

    double process(double input){
        double mix=mixSm.next();if(mix<0.001)return input;
        double output=0;
        for(int i=0;i<NUM_BANDS;++i){
            double modBand=modFilters[i].process(input,freqs[i],bandQ[i],sr);
            double env=envFollowers[i].process(modBand);
            double carBand=carrierFilters[i].process(input,freqs[i],bandQ[i],sr);
            double bandGain=bandGainSm[i].next();
            output+=carBand*env*bandGain*5.0; // was 4.0, slightly more presence
        }
        return input*(1-mix)+output*mix;
    }
};

// ═══════════ COMB FILTER ════════════════════════════════════
// Enhanced: added a second allpass in the negative-feedback loop
// for richer, more organic tube resonance. Slightly higher
// feedback ceiling (0.97 -> 0.98) for longer, glowing decay.

struct CombFilter {
    static constexpr int MAX_D=4096;
    double buf[MAX_D]{};int wp=0;double lpSt=0,apSt1=0,apSt2=0,sr=44100;bool negMode=false;
    void prepare(double s,bool neg){sr=s;negMode=neg;std::memset(buf,0,sizeof(buf));wp=0;lpSt=0;apSt1=0;apSt2=0;}
    double process(double input,double freq,double feedback,double tone){
        double ds=sr/std::max(freq,20.0);ds=std::min(ds,(double)(MAX_D-2));
        int d=(int)ds;double fr=ds-d;int i0=(wp-d+MAX_D)%MAX_D,i1=(i0-1+MAX_D)%MAX_D;
        double delayed=buf[i0]*(1-fr)+buf[i1]*fr;
        // LP damping in feedback
        double lc=0.02+tone*0.95;lpSt+=lc*(delayed-lpSt);
        double fb=std::clamp(feedback,0.0,0.98),fbs=lpSt*fb;
        if(negMode){
            fbs=-fbs;
            // Two cascaded allpass stages for richer dispersion
            // Creates more organic, less metallic tube resonance
            double apc1=0.45,api1=fbs,apo1=-apc1*api1+apSt1;apSt1=api1+apc1*apo1;
            double apc2=0.35,api2=apo1,apo2=-apc2*api2+apSt2;apSt2=api2+apc2*apo2;
            fbs=apo2;
        }
        buf[wp]=input+fbs;wp=(wp+1)%MAX_D;return delayed;}
};

// ═══════════ DUST EXCITER ═══════════════════════════════════

struct DustExciter {
    double heldGain=1,counter=0,envelope=0,envA=0,envR=0,sr=44100;
    uint32_t rng=48271;double nextRand(){rng=rng*1664525u+1013904223u;return(double)(rng&0xFFFFFF)/(double)0xFFFFFF;}
    void prepare(double s){sr=s;heldGain=1;counter=0;envelope=0;envA=1-std::exp(-1/(0.001*s));envR=1-std::exp(-1/(0.030*s));}
    double process(double input,double amount,double spread){
        if(amount<0.001)return input;double absIn=std::abs(input);envelope+=((absIn>envelope)?envA:envR)*(absIn-envelope);
        double rateHz=5.0*std::pow(400.0,amount),interval=sr/rateHz;counter-=1.0;
        if(counter<=0.0){double variation=(nextRand()*2-1)*envelope*amount*8.0;heldGain=std::clamp(1.0+variation,0.05,4.0);
            double minJ=0.9-spread*0.85,maxJ=1.1+spread*4.0;counter=std::clamp(interval*(minJ+nextRand()*(maxJ-minJ)),1.0,sr);}
        return input*heldGain;}
};

// ═══════════ PLATE REVERB ═══════════════════════════════════

struct PlateReverb {
    static constexpr int AP_LENS[4]={142,107,379,277};static constexpr int MAX_AP=512;
    double apMem[4][MAX_AP]{};int apWp[4]{};
    static constexpr int DL_LENS[4]={4799,5399,6199,7001};static constexpr int MAX_DL=8000;
    double dlMem[4][MAX_DL]{};int dlWp[4]{};double dlLp[4]{};
    double outLp1=0,outLp2=0;
    void prepare(){for(int i=0;i<4;++i){std::memset(apMem[i],0,sizeof(double)*AP_LENS[i]);apWp[i]=0;std::memset(dlMem[i],0,sizeof(double)*DL_LENS[i]);dlWp[i]=0;dlLp[i]=0;}outLp1=outLp2=0;}
    double processAP(int idx,double in,double g){int len=AP_LENS[idx];int rp=(apWp[idx]-len+len*2)%len;double del=apMem[idx][rp];double tmp=in+del*g;apMem[idx][apWp[idx]]=tmp;apWp[idx]=(apWp[idx]+1)%len;return del-tmp*g;}
    double process(double input,double amount){
        if(amount<0.001)return input;double diffused=input;for(int i=0;i<4;++i)diffused=processAP(i,diffused,0.6);
        double tankOut=0,decay=0.5+amount*0.45,damping=0.2+amount*0.35;
        for(int i=0;i<4;++i){int len=DL_LENS[i];int rp=(dlWp[i]-len+len*2)%len;double delayed=dlMem[i][rp];dlLp[i]+=damping*(delayed-dlLp[i]);dlMem[i][dlWp[i]]=diffused*0.25+dlLp[i]*decay;dlWp[i]=(dlWp[i]+1)%len;tankOut+=delayed;}
        tankOut*=0.25;double bits=14-amount*2;double levels=std::pow(2.0,bits);tankOut=std::round(tankOut*levels)/levels;
        outLp1+=0.35*(tankOut-outLp1);outLp2+=0.45*(outLp1-outLp2);return input*(1-amount*0.3)+outLp2*amount*2.5;}
};

// ═══════════ RESONATOR BAND ═════════════════════════════════

struct ResonatorBand {
    SVFBandpass filter;Vactrol vactrol;CombFilter comb;DustExciter dust;
    Smoother freqSm,emphSm,gainSm,dustSm,spreadSm,combSm,combFreqSm,combToneSm,crushSm;
    void prepare(double sr,bool negComb){filter.reset();vactrol.prepare(sr);comb.prepare(sr,negComb);dust.prepare(sr);freqSm.prepare(sr,15);emphSm.prepare(sr,15);gainSm.prepare(sr,15);dustSm.prepare(sr,20);spreadSm.prepare(sr,20);combSm.prepare(sr,20);combFreqSm.prepare(sr,15);combToneSm.prepare(sr,20);crushSm.prepare(sr,20);}
    double process(double input,double sr,double lfoMod=1.0){
        double freq=freqSm.next()*lfoMod,emph=emphSm.next(),gain=gainSm.next();
        double dustAmt=dustSm.next(),spread=spreadSm.next();
        double combAmt=combSm.next(),combF=combFreqSm.next(),combT=combToneSm.next(),crush=crushSm.next();
        double sf=vactrol.process(std::clamp(freq,20.0,sr*0.45));
        double filterIn=dust.process(input,dustAmt,spread);
        double bp=filter.process(filterIn,sf,emph,sr);
        if(combAmt>0.001){
            double co=comb.process(bp,sf*combF,combAmt*0.95,combT);
            // Blend: more comb in the mix for that glowing resonance
            bp=bp*(1-combAmt*0.7)+co*combAmt*0.7;
        }
        bp=bitCrush(bp,crush);return bp*gain;}
};

// ═══════════ FULL ENGINE ════════════════════════════════════

struct Resonator {
    static constexpr int NumBands=3;
    MultibandDelay mbDelay;FreqShifter freqShift;Vocoder vocoder;
    ResonatorBand bands[NumBands];DCBlocker dcBlocker;PlateReverb verb;
    Smoother mixSm,lfoRateSm,lfoDepthSm,verbSm;
    double lfoPhase=0,sampleRate=44100;
    void prepare(double sr){sampleRate=sr;lfoPhase=0;dcBlocker.reset();verb.prepare();mbDelay.prepare(sr);freqShift.prepare(sr);vocoder.prepare(sr);mixSm.prepare(sr,20);lfoRateSm.prepare(sr,50);lfoDepthSm.prepare(sr,30);verbSm.prepare(sr,20);bands[0].prepare(sr,false);bands[1].prepare(sr,true);bands[2].prepare(sr,true);}
    double process(double input){
        double preProc=mbDelay.process(input);preProc=freqShift.process(preProc);preProc=vocoder.process(preProc);
        double rate=lfoRateSm.next(),depth=lfoDepthSm.next();lfoPhase+=rate/sampleRate;if(lfoPhase>1)lfoPhase-=1;double lfo=(lfoPhase<0.5)?(lfoPhase*4-1):(3-lfoPhase*4);double lfoMod=1+lfo*depth*0.5;
        double x=softClip(preProc);double wet=0;for(auto&b:bands)wet+=b.process(x,sampleRate,lfoMod);wet=softClip(wet*0.7);wet=dcBlocker.process(wet);wet=verb.process(wet,verbSm.next());
        double m=mixSm.next();return input*(1-m)+wet*m;}
};

} // namespace ps3100
