#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include "PluginProcessor.h"

namespace Cols {
    const juce::Colour bg(0xff0e1118),panel(0xff151a24),panelBorder(0xff1e2535),panelInner(0xff111620);
    const juce::Colour fawn(0xffc4a77d),teal(0xff70877f),indigo(0xff454372),periwinkle(0xff8884ff);
    const juce::Colour ash(0xffb4b8ab),text(0xff9a9eb0),textDim(0xff555a6e),taupe(0xff5d576b);
    const juce::Colour dust(0xffff9966),combCol(0xff66ccbb),verbCol(0xff9988dd),crushCol(0xffee465d);
}

class PS3100LnF:public juce::LookAndFeel_V4{
public:
    PS3100LnF(){setColour(juce::Slider::textBoxTextColourId,Cols::text);setColour(juce::Slider::textBoxOutlineColourId,juce::Colours::transparentBlack);setColour(juce::Slider::textBoxBackgroundColourId,Cols::panelInner);setColour(juce::Label::textColourId,Cols::textDim);}
    void drawRotarySlider(juce::Graphics&g,int x,int y,int w,int h,float pos,float sa,float ea,juce::Slider&sl)override{
        float r=(float)juce::jmin(w,h)*0.5f-4,cx=(float)x+w*0.5f,cy=(float)y+h*0.5f,ang=sa+pos*(ea-sa);auto ac=sl.findColour(juce::Slider::thumbColourId);float hp=juce::MathConstants<float>::halfPi;
        for(int i=0;i<11;++i){float t=(float)i/10.f,ta=sa+t*(ea-sa),r1=r+2,r2=r+6;g.setColour((t<=pos+0.01f)?ac.withAlpha(0.5f):Cols::panelBorder);g.drawLine(cx+r1*std::cos(ta-hp),cy+r1*std::sin(ta-hp),cx+r2*std::cos(ta-hp),cy+r2*std::sin(ta-hp),1.5f);}
        juce::ColourGradient bg(juce::Colour(0xff2a3040),cx-r*0.3f,cy-r*0.3f,juce::Colour(0xff10141c),cx+r*0.3f,cy+r*0.3f,true);g.setGradientFill(bg);g.fillEllipse(cx-r,cy-r,r*2,r*2);g.setColour(juce::Colour(0xff1a2030));g.drawEllipse(cx-r,cy-r,r*2,r*2,1.5f);
        float ll=r-7;g.setColour(ac);g.drawLine(cx,cy,cx+ll*std::cos(ang-hp),cy+ll*std::sin(ang-hp),2.5f);g.setColour(juce::Colour(0xff1a1f2a));g.fillEllipse(cx-3,cy-3,6,6);}
    void drawLinearSlider(juce::Graphics&g,int x,int y,int w,int h,float pos,float,float,juce::Slider::SliderStyle,juce::Slider&sl)override{
        auto ac=sl.findColour(juce::Slider::thumbColourId);float ty=(float)y+h*0.5f;g.setColour(Cols::panelBorder);g.fillRoundedRectangle((float)x,ty-2,(float)w,4,2);g.setColour(ac.withAlpha(0.4f));g.fillRoundedRectangle((float)x,ty-2,pos-(float)x,4,2);g.setColour(ac);g.fillEllipse(pos-4,ty-4,8,8);}
    juce::Label*createSliderTextBox(juce::Slider&s)override{auto*l=LookAndFeel_V4::createSliderTextBox(s);l->setFont(juce::FontOptions(9.f));return l;}
};

class SpecComp:public juce::Component,public juce::Timer{
public:
    SpecComp(PS3100ResonatorProcessor&p):proc(p),fft(p.fftOrder){startTimerHz(30);}
    void timerCallback()override{if(proc.nextFFTBlockReady){fft.performFrequencyOnlyForwardTransform(proc.fftData.data());proc.nextFFTBlockReady=false;for(int i=0;i<256;++i){float f=20.f*std::pow(1000.f,(float)i/256.f);int bin=juce::jlimit(0,proc.fftSize/2-1,(int)(f/(proc.currentSampleRate/(float)proc.fftSize)));float db=juce::jlimit(-80.f,0.f,juce::Decibels::gainToDecibels(proc.fftData[(size_t)bin]/(float)proc.fftSize));sc[(size_t)i]=sc[(size_t)i]*0.7f+((db+80.f)/80.f)*0.3f;}repaint();}}
    void paint(juce::Graphics&g)override{auto b=getLocalBounds().toFloat();g.setColour(Cols::panelInner);g.fillRoundedRectangle(b,6);g.setColour(Cols::panelBorder);g.drawRoundedRectangle(b,6,1);float gf[]={50,100,200,500,1000,2000,5000,10000};for(float f:gf){float x=fX(f,b);g.setColour(juce::Colour(0xff1a2030));g.drawLine(x,b.getY(),x,b.getBottom(),0.5f);g.setFont(juce::FontOptions(7.f));g.setColour(juce::Colour(0xff2a3045));g.drawText(f>=1000?juce::String(f/1000,0)+"k":juce::String((int)f),(int)x+2,(int)b.getBottom()-12,30,10,juce::Justification::left);}
        auto mk=[&](const char*p,juce::Colour c){float x=fX(proc.apvts.getRawParameterValue(p)->load(),b);g.setColour(c.withAlpha(0.3f));for(float y=b.getY();y<b.getBottom();y+=6)g.drawLine(x,y,x,juce::jmin(y+3,b.getBottom()),1.f);};mk(PS3100ResonatorProcessor::PB1F,Cols::fawn);mk(PS3100ResonatorProcessor::PB2F,Cols::periwinkle);mk(PS3100ResonatorProcessor::PB3F,Cols::teal);
        juce::Path path;for(int i=0;i<256;++i){float x=b.getX()+(float)i/256.f*b.getWidth();float y=b.getBottom()-sc[(size_t)i]*b.getHeight()*0.9f;if(i==0)path.startNewSubPath(x,y);else path.lineTo(x,y);}juce::Path fp(path);fp.lineTo(b.getRight(),b.getBottom());fp.lineTo(b.getX(),b.getBottom());fp.closeSubPath();g.setGradientFill(juce::ColourGradient(Cols::periwinkle.withAlpha(0.3f),0,b.getY(),Cols::indigo.withAlpha(0.05f),0,b.getBottom(),false));g.fillPath(fp);g.setColour(Cols::periwinkle.withAlpha(0.6f));g.strokePath(path,juce::PathStrokeType(1.5f));}
private:PS3100ResonatorProcessor&proc;juce::dsp::FFT fft;std::array<float,256>sc{};float fX(float f,juce::Rectangle<float>b)const{return b.getX()+std::log(f/20.f)/std::log(1000.f)*b.getWidth();}
};

struct Knob{juce::Slider slider;juce::Label label;std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>att;
    void init(juce::Component&p,juce::AudioProcessorValueTreeState&a,const juce::String&pid,const juce::String&nm,juce::Colour c,PS3100LnF&lnf){slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);slider.setTextBoxStyle(juce::Slider::TextBoxBelow,false,50,12);slider.setColour(juce::Slider::thumbColourId,c);slider.setColour(juce::Slider::rotarySliderFillColourId,c);slider.setLookAndFeel(&lnf);p.addAndMakeVisible(slider);label.setText(nm,juce::dontSendNotification);label.setFont(juce::FontOptions(7.f));label.setColour(juce::Label::textColourId,Cols::textDim);label.setJustificationType(juce::Justification::centred);p.addAndMakeVisible(label);att=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(a,pid,slider);}
    void place(int x,int y,int sz){label.setBounds(x,y,sz+8,10);slider.setBounds(x,y+10,sz+8,sz+14);}};

struct HSl{juce::Slider slider;juce::Label label;std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>att;
    void init(juce::Component&p,juce::AudioProcessorValueTreeState&a,const juce::String&pid,const juce::String&nm,juce::Colour c,PS3100LnF&lnf){slider.setSliderStyle(juce::Slider::LinearHorizontal);slider.setTextBoxStyle(juce::Slider::NoTextBox,true,0,0);slider.setColour(juce::Slider::thumbColourId,c);slider.setLookAndFeel(&lnf);p.addAndMakeVisible(slider);label.setText(nm,juce::dontSendNotification);label.setFont(juce::FontOptions(7.f));label.setColour(juce::Label::textColourId,Cols::textDim);label.setJustificationType(juce::Justification::left);p.addAndMakeVisible(label);att=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(a,pid,slider);}
    void place(int x,int y,int lw,int sw){label.setBounds(x,y,lw,13);slider.setBounds(x+lw,y,sw,13);}};

class PS3100ResonatorEditor:public juce::AudioProcessorEditor{
public:
    explicit PS3100ResonatorEditor(PS3100ResonatorProcessor&p):AudioProcessorEditor(p),proc(p),spec(p){
        setSize(740,620);addAndMakeVisible(spec);
        volIn.init(*this,p.apvts,p.PIG,"VOL IN",Cols::ash,lnf);lfoR.init(*this,p.apvts,p.PLFOR,"LFO RATE",Cols::taupe,lnf);lfoD.init(*this,p.apvts,p.PLFOD,"LFO DEPTH",Cols::taupe,lnf);vrb.init(*this,p.apvts,p.PVERB,"VERB",Cols::verbCol,lnf);mix.init(*this,p.apvts,p.PMIX,"MIX",Cols::periwinkle,lnf);volOut.init(*this,p.apvts,p.POG,"VOL OUT",Cols::ash,lnf);
        auto ib=[&](Knob&fr,Knob&em,Knob&cm,Knob&ga,Knob&du,Knob&sp,HSl&cf,HSl&ct,HSl&cr,const char*a,const char*b,const char*c,const char*d,const char*e,const char*f,const char*g,const char*h,const char*j,juce::Colour bc){fr.init(*this,p.apvts,a,"FREQ",bc,lnf);em.init(*this,p.apvts,b,"EMPH",bc,lnf);cm.init(*this,p.apvts,c,"COMB",Cols::combCol,lnf);ga.init(*this,p.apvts,d,"GAIN",bc,lnf);du.init(*this,p.apvts,e,"DUST",Cols::dust,lnf);sp.init(*this,p.apvts,f,"SPREAD",Cols::dust,lnf);cf.init(*this,p.apvts,g,"COMB FREQ",Cols::combCol,lnf);ct.init(*this,p.apvts,h,"COMB TONE",Cols::combCol,lnf);cr.init(*this,p.apvts,j,"CRUSH",Cols::crushCol,lnf);};
        ib(b1Fr,b1Em,b1Cm,b1Ga,b1Du,b1Sp,b1Cf,b1Ct,b1Cr,p.PB1F,p.PB1E,p.PB1C,p.PB1G,p.PB1D,p.PB1S,p.PB1CF,p.PB1CT,p.PB1CR,Cols::fawn);
        ib(b2Fr,b2Em,b2Cm,b2Ga,b2Du,b2Sp,b2Cf,b2Ct,b2Cr,p.PB2F,p.PB2E,p.PB2C,p.PB2G,p.PB2D,p.PB2S,p.PB2CF,p.PB2CT,p.PB2CR,Cols::periwinkle);
        ib(b3Fr,b3Em,b3Cm,b3Ga,b3Du,b3Sp,b3Cf,b3Ct,b3Cr,p.PB3F,p.PB3E,p.PB3C,p.PB3G,p.PB3D,p.PB3S,p.PB3CF,p.PB3CT,p.PB3CR,Cols::teal);
    }
    ~PS3100ResonatorEditor()override{setLookAndFeel(nullptr);}

    void paint(juce::Graphics&g)override{
        g.fillAll(Cols::bg);auto area=getLocalBounds().reduced(10);g.setColour(Cols::panel);g.fillRoundedRectangle(area.toFloat(),10);g.setColour(Cols::panelBorder);g.drawRoundedRectangle(area.toFloat(),10,1);
        g.setColour(Cols::taupe);g.setFont(juce::FontOptions(9.f));g.drawText("KORG PS3100",24,16,200,14,juce::Justification::left);g.setColour(Cols::periwinkle);g.setFont(juce::FontOptions(22.f));g.drawText("RESONATOR",24,28,300,28,juce::Justification::left);g.setColour(Cols::textDim);g.setFont(juce::FontOptions(7.f));g.drawText("RESONATOR - COMB - DUST - CRUSH - PLATE VERB",24,54,600,10,juce::Justification::left);
        juce::Colour bc[]={Cols::fawn,Cols::periwinkle,Cols::teal};const char*bn[]={"BAND I","BAND II","BAND III"};const char*rng[]={"60-600 Hz","200-3k Hz","1k-12k Hz"};
        for(int i=0;i<3;++i){auto r=bRect(i);g.setColour(Cols::panel);g.fillRoundedRectangle(r,8);g.setColour(Cols::panelBorder);g.drawRoundedRectangle(r,8,1);int bx=(int)r.getX(),by=(int)r.getY(),bw=(int)r.getWidth(),bh=(int)r.getHeight();g.setColour(bc[i]);g.fillEllipse((float)bx+12,(float)by+10,6,6);g.setFont(juce::FontOptions(11.f));g.drawText(bn[i],bx+24,by+6,120,16,juce::Justification::left);g.setColour(Cols::textDim);g.setFont(juce::FontOptions(7.f));g.drawText(rng[i],bx,by+bh-14,bw,12,juce::Justification::centred);}
        g.setColour(Cols::textDim);g.setFont(juce::FontOptions(7.f));g.drawText("SVF BP - VACTROL CV - COMB - DUST - CRUSH - PLATE VERB",20,getHeight()-20,500,12,juce::Justification::left);g.drawText("DEPATTERN  v0.10",getWidth()-200,getHeight()-20,180,12,juce::Justification::right);
    }

    void resized()override{
        spec.setBounds(20,66,getWidth()-40,105);
        const int gy=178,ks=42,gap=4,cw=ks+8;
        volIn.place(20,gy,ks);lfoR.place(20+cw+gap,gy,ks);lfoD.place(20+(cw+gap)*2,gy,ks);vrb.place(20+(cw+gap)*3,gy,ks);
        int rx=getWidth()-20-(cw+gap)*2;mix.place(rx,gy,ks);volOut.place(rx+cw+gap,gy,ks);

        const int bks=40,bcw=bks+8,bch=bks+24+2;
        struct BK{Knob*fr,*em,*cm,*ga,*du,*sp;HSl*cf,*ct,*cr;};
        BK bk[3]={{&b1Fr,&b1Em,&b1Cm,&b1Ga,&b1Du,&b1Sp,&b1Cf,&b1Ct,&b1Cr},{&b2Fr,&b2Em,&b2Cm,&b2Ga,&b2Du,&b2Sp,&b2Cf,&b2Ct,&b2Cr},{&b3Fr,&b3Em,&b3Cm,&b3Ga,&b3Du,&b3Sp,&b3Cf,&b3Ct,&b3Cr}};
        for(int i=0;i<3;++i){auto r=bRect(i);int bx=(int)r.getX(),bw=(int)r.getWidth();int gridW=bcw*3+4;int sx=bx+(bw-gridW)/2;int r1=(int)r.getY()+26,r2=r1+bch;
            bk[i].fr->place(sx,r1,bks);bk[i].em->place(sx+bcw+2,r1,bks);bk[i].cm->place(sx+(bcw+2)*2,r1,bks);
            bk[i].ga->place(sx,r2,bks);bk[i].du->place(sx+bcw+2,r2,bks);bk[i].sp->place(sx+(bcw+2)*2,r2,bks);
            int fy=r2+bch+2,flw=55,fsw=bw-flw-20;
            bk[i].cf->place(bx+10,fy,flw,fsw);bk[i].ct->place(bx+10,fy+15,flw,fsw);bk[i].cr->place(bx+10,fy+30,flw,fsw);}
    }
private:
    PS3100ResonatorProcessor&proc;PS3100LnF lnf;SpecComp spec;
    Knob volIn,lfoR,lfoD,vrb,mix,volOut;
    Knob b1Fr,b1Em,b1Cm,b1Ga,b1Du,b1Sp;Knob b2Fr,b2Em,b2Cm,b2Ga,b2Du,b2Sp;Knob b3Fr,b3Em,b3Cm,b3Ga,b3Du,b3Sp;
    HSl b1Cf,b1Ct,b1Cr,b2Cf,b2Ct,b2Cr,b3Cf,b3Ct,b3Cr;
    juce::Rectangle<float>bRect(int i)const{const int bw=228,bh=258,by=250;int tw=bw*3+8*2,sx=(getWidth()-tw)/2;return{(float)(sx+i*(bw+8)),(float)by,(float)bw,(float)bh};}
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PS3100ResonatorEditor)
};
