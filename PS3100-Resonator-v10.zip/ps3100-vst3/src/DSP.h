#pragma once
#include <cmath>
#include <algorithm>
#include <cstring>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

namespace ps3100 {

struct SVFBandpass {
    double low=0,band=0,high=0;
    void reset(){low=band=high=0;}
    double process(double in,double freq,double q,double sr){
        double f=2*std::sin(M_PI*std::min(freq,sr*0.45)/sr),qi=1/std::max(q,0.5);
        for(int i=0;i<2;++i){low+=f*band;high=in-low-qi*band;band+=f*high;}return band;}
};

struct Vactrol {
    double state=0,ac=0,rc=0;
    void prepare(double sr){ac=1-std::exp(-1/(0.005*sr));rc=1-std::exp(-1/(0.05*sr));state=0;}
    double process(double t){state+=((t>state)?ac:rc)*(t-state);return state;}
};

inline double softClip(double x){double xg=x*1.8;return std::tanh(xg*0.9)+0.05*std::tanh(xg*3.0);}

struct DCBlocker {
    double x1=0,y1=0;
    double process(double x){y1=x-x1+0.9995*y1;x1=x;return y1;}
    void reset(){x1=y1=0;}
};

struct Smoother {
    double target=0,current=0,coeff=0;
    void prepare(double sr,double ms=20){coeff=1-std::exp(-1/(ms*0.001*sr));current=target;}
    void setTarget(double t){target=t;}
    double next(){current+=coeff*(target-current);return current;}
};

// Comb Filter: Band1=positive fb (metallic), Bands2&3=negative fb + allpass (hollow tube)
struct CombFilter {
    static constexpr int MAX_D=4096;
    double buf[MAX_D]{};int wp=0;double lpSt=0,apSt=0,sr=44100;bool negMode=false;
    void prepare(double s,bool neg){sr=s;negMode=neg;std::memset(buf,0,sizeof(buf));wp=0;lpSt=0;apSt=0;}
    double process(double input,double freq,double feedback,double tone){
        double ds=sr/std::max(freq,20.0);ds=std::min(ds,(double)(MAX_D-2));
        int d=(int)ds;double fr=ds-d;int i0=(wp-d+MAX_D)%MAX_D,i1=(i0-1+MAX_D)%MAX_D;
        double delayed=buf[i0]*(1-fr)+buf[i1]*fr;
        double lc=0.02+tone*0.95;lpSt+=lc*(delayed-lpSt);
        double fb=std::clamp(feedback,0.0,0.97),fbs=lpSt*fb;
        if(negMode){fbs=-fbs;double apc=0.5,api=fbs,apo=-apc*api+apSt;apSt=api+apc*apo;fbs=apo;}
        buf[wp]=input+fbs;wp=(wp+1)%MAX_D;return delayed;}
};

// Dust Exciter: S&H gain modulator
struct DustExciter {
    double heldGain=1,counter=0,envelope=0,envA=0,envR=0,sr=44100;
    uint32_t rng=48271;
    double nextRand(){rng=rng*1664525u+1013904223u;return(double)(rng&0xFFFFFF)/(double)0xFFFFFF;}
    void prepare(double s){sr=s;heldGain=1;counter=0;envelope=0;envA=1-std::exp(-1/(0.001*s));envR=1-std::exp(-1/(0.030*s));}
    double process(double input,double amount,double spread){
        if(amount<0.001)return input;
        double absIn=std::abs(input);envelope+=((absIn>envelope)?envA:envR)*(absIn-envelope);
        double rateHz=5.0*std::pow(400.0,amount),interval=sr/rateHz;
        counter-=1.0;
        if(counter<=0.0){
            double variation=(nextRand()*2-1)*envelope*amount*8.0;
            heldGain=std::clamp(1.0+variation,0.05,4.0);
            double minJ=0.9-spread*0.85,maxJ=1.1+spread*4.0;
            counter=std::clamp(interval*(minJ+nextRand()*(maxJ-minJ)),1.0,sr);}
        return input*heldGain;}
};

// Bit Crusher: reduces bit depth for sparkly/glassy artifacts
inline double bitCrush(double x, double amount) {
    if(amount<0.001) return x;
    // 16-bit clean down to ~4-bit crushed
    double bits = 16.0 - amount * 12.0;
    double levels = std::pow(2.0, bits);
    return std::round(x * levels) / levels;
}

// Plate-style Reverb: spacious, ethereal, cavernous
// Uses a network of allpass diffusers + parallel delay lines with LP feedback
// for a wide ambient decay, with subtle bit reduction for lo-fi shimmer
struct PlateReverb {
    // Diffusion: 4 allpass stages
    static constexpr int AP_LENS[4] = {142, 107, 379, 277};
    static constexpr int MAX_AP = 512;
    double apMem[4][MAX_AP]{};
    int apWp[4]{};

    // Tank: 4 parallel delay lines with feedback (simulates plate reflections)
    static constexpr int DL_LENS[4] = {3163, 3907, 4799, 5399};
    static constexpr int MAX_DL = 6000;
    double dlMem[4][MAX_DL]{};
    int dlWp[4]{};

    // LP in each feedback path (damping)
    double dlLp[4]{};

    // Output LP for smoothing
    double outLp1=0, outLp2=0;

    void prepare() {
        for(int i=0;i<4;++i){std::memset(apMem[i],0,sizeof(double)*AP_LENS[i]);apWp[i]=0;
            std::memset(dlMem[i],0,sizeof(double)*DL_LENS[i]);dlWp[i]=0;dlLp[i]=0;}
        outLp1=outLp2=0;
    }

    double processAP(int idx, double in, double g) {
        int len=AP_LENS[idx];int rp=(apWp[idx]-len+len*2)%len;
        double del=apMem[idx][rp];double tmp=in+del*g;
        apMem[idx][apWp[idx]]=tmp;apWp[idx]=(apWp[idx]+1)%len;
        return del-tmp*g;
    }

    double process(double input, double amount) {
        if(amount<0.001) return input;

        // Pre-diffusion through allpass chain
        double diffused = input;
        double apG = 0.6;
        for(int i=0;i<4;++i) diffused = processAP(i, diffused, apG);

        // Feed into 4 parallel delay lines
        double tankOut = 0;
        double decay = 0.45 + amount * 0.45;  // 0.45 to 0.90
        double damping = 0.3 + amount * 0.3;  // LP amount in feedback

        for(int i=0;i<4;++i) {
            int len = DL_LENS[i];
            int rp = (dlWp[i] - len + len*2) % len;
            double delayed = dlMem[i][rp];

            // LP damping in feedback
            dlLp[i] += damping * (delayed - dlLp[i]);

            // Cross-feed: each line feeds from diffused input + other lines' feedback
            double fbSignal = dlLp[i] * decay;
            dlMem[i][dlWp[i]] = diffused * 0.25 + fbSignal;
            dlWp[i] = (dlWp[i] + 1) % len;

            tankOut += delayed;
        }
        tankOut *= 0.25;

        // Subtle bit reduction for that vintage digital shimmer
        double bits = 14.0 - amount * 2.0;  // 14 down to 12 bit — subtle
        double levels = std::pow(2.0, bits);
        tankOut = std::round(tankOut * levels) / levels;

        // Smooth output
        outLp1 += 0.4 * (tankOut - outLp1);
        outLp2 += 0.5 * (outLp1 - outLp2);

        return input * (1.0 - amount * 0.4) + outLp2 * amount * 0.8;
    }
};

// Resonator Band
struct ResonatorBand {
    SVFBandpass filter;Vactrol vactrol;CombFilter comb;DustExciter dust;
    Smoother freqSm,emphSm,gainSm,dustSm,spreadSm,combSm,combFreqSm,combToneSm,crushSm;

    void prepare(double sr,bool negComb){
        filter.reset();vactrol.prepare(sr);comb.prepare(sr,negComb);dust.prepare(sr);
        freqSm.prepare(sr,15);emphSm.prepare(sr,15);gainSm.prepare(sr,15);
        dustSm.prepare(sr,20);spreadSm.prepare(sr,20);
        combSm.prepare(sr,20);combFreqSm.prepare(sr,15);combToneSm.prepare(sr,20);
        crushSm.prepare(sr,20);
    }

    double process(double input,double sr,double lfoMod=1.0){
        double freq=freqSm.next()*lfoMod,emph=emphSm.next(),gain=gainSm.next();
        double dustAmt=dustSm.next(),spread=spreadSm.next();
        double combAmt=combSm.next(),combF=combFreqSm.next(),combT=combToneSm.next();
        double crush=crushSm.next();
        double sf=vactrol.process(std::clamp(freq,20.0,sr*0.45));

        // Dust exciter
        double filterIn=dust.process(input,dustAmt,spread);
        // Bandpass filter
        double bp=filter.process(filterIn,sf,emph,sr);
        // Comb filter
        if(combAmt>0.001){double co=comb.process(bp,sf*combF,combAmt*0.95,combT);bp=bp*(1-combAmt*0.6)+co*combAmt*0.6;}
        // Bit crusher (post-comb)
        bp = bitCrush(bp, crush);
        return bp*gain;
    }
};

// Full Engine
struct Resonator {
    static constexpr int NumBands=3;
    ResonatorBand bands[NumBands];
    DCBlocker dcBlocker;PlateReverb verb;
    Smoother mixSm,lfoRateSm,lfoDepthSm,verbSm;
    double lfoPhase=0,sampleRate=44100;

    void prepare(double sr){
        sampleRate=sr;lfoPhase=0;dcBlocker.reset();verb.prepare();
        mixSm.prepare(sr,20);lfoRateSm.prepare(sr,50);lfoDepthSm.prepare(sr,30);verbSm.prepare(sr,20);
        bands[0].prepare(sr,false);bands[1].prepare(sr,true);bands[2].prepare(sr,true);}

    double process(double input){
        double rate=lfoRateSm.next(),depth=lfoDepthSm.next();
        lfoPhase+=rate/sampleRate;if(lfoPhase>1)lfoPhase-=1;
        double lfo=(lfoPhase<0.5)?(lfoPhase*4-1):(3-lfoPhase*4);
        double lfoMod=1+lfo*depth*0.5;
        double x=softClip(input);
        double wet=0;for(auto&b:bands)wet+=b.process(x,sampleRate,lfoMod);
        wet=softClip(wet*0.7);wet=dcBlocker.process(wet);
        wet=verb.process(wet,verbSm.next());
        double m=mixSm.next();return input*(1-m)+wet*m;}
};

} // namespace ps3100
