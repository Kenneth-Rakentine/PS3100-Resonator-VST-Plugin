#include "PluginProcessor.h"
#include "PluginEditor.h"

juce::AudioProcessorValueTreeState::ParameterLayout PS3100ResonatorProcessor::createParameterLayout(){
    std::vector<std::unique_ptr<juce::RangedAudioParameter>>p;
    auto fR=[](float lo,float hi){return juce::NormalisableRange<float>(lo,hi,[](float l,float h,float n){return l*std::pow(h/l,n);},[](float l,float h,float v){return std::log(v/l)/std::log(h/l);});};
    auto fL=[](float v,int){return v>=1000?juce::String(v/1000,1)+" kHz":juce::String((int)v)+" Hz";};
    auto addB=[&](const char*fId,const char*eId,const char*gId,const char*dId,const char*sId,const char*cId,const char*cfId,const char*ctId,const char*crId,const char*nm,float fLo,float fHi,float fDef){
        p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{fId,1},juce::String(nm)+" Freq",fR(fLo,fHi),fDef,juce::String(),juce::AudioProcessorParameter::genericParameter,fL));
        p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{eId,1},juce::String(nm)+" Emph",juce::NormalisableRange<float>(0.5f,40,0.1f,0.4f),4.f));
        p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{gId,1},juce::String(nm)+" Gain",juce::NormalisableRange<float>(-60,12,0.1f),0.f,"dB"));
        p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{dId,1},juce::String(nm)+" Dust",juce::NormalisableRange<float>(0,100,0.1f),0.f,"%"));
        p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{sId,1},juce::String(nm)+" Spread",juce::NormalisableRange<float>(0,100,0.1f),50.f,"%"));
        p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{cId,1},juce::String(nm)+" Comb",juce::NormalisableRange<float>(0,100,0.1f),0.f,"%"));
        p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{cfId,1},juce::String(nm)+" CombFreq",juce::NormalisableRange<float>(0.5f,2.0f,0.01f),1.f,"x"));
        p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{ctId,1},juce::String(nm)+" CombTone",juce::NormalisableRange<float>(0,100,0.1f),60.f,"%"));
        p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{crId,1},juce::String(nm)+" Crush",juce::NormalisableRange<float>(0,100,0.1f),0.f,"%"));
    };
    addB(PB1F,PB1E,PB1G,PB1D,PB1S,PB1C,PB1CF,PB1CT,PB1CR,"Band I",60,600,180);
    addB(PB2F,PB2E,PB2G,PB2D,PB2S,PB2C,PB2CF,PB2CT,PB2CR,"Band II",200,3000,800);
    addB(PB3F,PB3E,PB3G,PB3D,PB3S,PB3C,PB3CF,PB3CT,PB3CR,"Band III",1000,12000,4000);
    p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{PMIX,1},"Mix",juce::NormalisableRange<float>(0,100,0.1f),70.f,"%"));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{PLFOR,1},"LFO Rate",juce::NormalisableRange<float>(0.01f,12,0.01f,0.35f),0.3f,"Hz"));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{PLFOD,1},"LFO Depth",juce::NormalisableRange<float>(0,100,0.1f),0.f,"%"));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{PIG,1},"Input Gain",juce::NormalisableRange<float>(-24,12,0.1f),0.f,"dB"));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{POG,1},"Output Gain",juce::NormalisableRange<float>(-24,12,0.1f),0.f,"dB"));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{PVERB,1},"Verb",juce::NormalisableRange<float>(0,100,0.1f),0.f,"%"));
    return{p.begin(),p.end()};
}

PS3100ResonatorProcessor::PS3100ResonatorProcessor():AudioProcessor(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true).withOutput("Output",juce::AudioChannelSet::stereo(),true)),apvts(*this,nullptr,"PS3100_PARAMS",createParameterLayout()){}
void PS3100ResonatorProcessor::prepareToPlay(double sr,int){currentSampleRate=sr;resonatorL.prepare(sr);resonatorR.prepare(sr);fifoIndex=0;nextFFTBlockReady=false;}

void PS3100ResonatorProcessor::processBlock(juce::AudioBuffer<float>&buf,juce::MidiBuffer&){
    juce::ScopedNoDenormals nd;int ns=buf.getNumSamples(),nc=buf.getNumChannels();
    struct BP{float f,e,g,d,s,c,cf,ct,cr;};
    auto rb=[&](const char*a,const char*b,const char*c,const char*d,const char*e,const char*f,const char*g,const char*h,const char*j)->BP{
        return{apvts.getRawParameterValue(a)->load(),apvts.getRawParameterValue(b)->load(),apvts.getRawParameterValue(c)->load(),apvts.getRawParameterValue(d)->load(),apvts.getRawParameterValue(e)->load(),apvts.getRawParameterValue(f)->load(),apvts.getRawParameterValue(g)->load(),apvts.getRawParameterValue(h)->load(),apvts.getRawParameterValue(j)->load()};};
    BP bp[3]={rb(PB1F,PB1E,PB1G,PB1D,PB1S,PB1C,PB1CF,PB1CT,PB1CR),rb(PB2F,PB2E,PB2G,PB2D,PB2S,PB2C,PB2CF,PB2CT,PB2CR),rb(PB3F,PB3E,PB3G,PB3D,PB3S,PB3C,PB3CF,PB3CT,PB3CR)};
    float mix=apvts.getRawParameterValue(PMIX)->load(),lr=apvts.getRawParameterValue(PLFOR)->load(),ld=apvts.getRawParameterValue(PLFOD)->load();
    float igDb=apvts.getRawParameterValue(PIG)->load(),ogDb=apvts.getRawParameterValue(POG)->load(),verb=apvts.getRawParameterValue(PVERB)->load();
    float inG=std::pow(10.f,igDb/20.f),outG=std::pow(10.f,ogDb/20.f);
    auto sp=[&](ps3100::Resonator&r){for(int i=0;i<3;++i){r.bands[i].freqSm.setTarget(bp[i].f);r.bands[i].emphSm.setTarget(bp[i].e);r.bands[i].gainSm.setTarget(std::pow(10.0,bp[i].g/20.0));r.bands[i].dustSm.setTarget(bp[i].d/100.0);r.bands[i].spreadSm.setTarget(bp[i].s/100.0);r.bands[i].combSm.setTarget(bp[i].c/100.0);r.bands[i].combFreqSm.setTarget(bp[i].cf);r.bands[i].combToneSm.setTarget(bp[i].ct/100.0);r.bands[i].crushSm.setTarget(bp[i].cr/100.0);}r.mixSm.setTarget(mix/100.0);r.lfoRateSm.setTarget(lr);r.lfoDepthSm.setTarget(ld/100.0);r.verbSm.setTarget(verb/100.0);};
    sp(resonatorL);sp(resonatorR);
    ps3100::Resonator*eng[2]={&resonatorL,&resonatorR};
    for(int ch=0;ch<std::min(nc,2);++ch){float*data=buf.getWritePointer(ch);auto&r=*eng[ch];for(int i=0;i<ns;++i){double s=(double)data[i]*inG;s=r.process(s);float out=(float)(s*outG);data[i]=out;if(ch==0)pushSampleToFifo(out);}}
    if(nc==1&&buf.getNumChannels()>=2)buf.copyFrom(1,0,buf,0,0,ns);
}

void PS3100ResonatorProcessor::getStateInformation(juce::MemoryBlock&d){auto s=apvts.copyState();std::unique_ptr<juce::XmlElement>x(s.createXml());copyXmlToBinary(*x,d);}
void PS3100ResonatorProcessor::setStateInformation(const void*d,int sz){std::unique_ptr<juce::XmlElement>x(getXmlFromBinary(d,sz));if(x&&x->hasTagName(apvts.state.getType()))apvts.replaceState(juce::ValueTree::fromXml(*x));}
juce::AudioProcessorEditor* PS3100ResonatorProcessor::createEditor(){return new PS3100ResonatorEditor(*this);}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter(){return new PS3100ResonatorProcessor();}
