#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include "PluginProcessor.h"

namespace Cols
{
    const juce::Colour bg          (0xff0e1118);
    const juce::Colour panel       (0xff151a24);
    const juce::Colour panelBorder (0xff1e2535);
    const juce::Colour panelInner  (0xff111620);
    const juce::Colour fawn        (0xffc4a77d);
    const juce::Colour teal        (0xff70877f);
    const juce::Colour indigo      (0xff454372);
    const juce::Colour periwinkle  (0xff8884ff);
    const juce::Colour ash         (0xffb4b8ab);
    const juce::Colour text        (0xff9a9eb0);
    const juce::Colour textDim     (0xff555a6e);
    const juce::Colour taupe       (0xff5d576b);
    const juce::Colour dust        (0xffff9966);
}

class PS3100LookAndFeel : public juce::LookAndFeel_V4
{
public:
    PS3100LookAndFeel()
    {
        setColour (juce::Slider::textBoxTextColourId,       Cols::text);
        setColour (juce::Slider::textBoxOutlineColourId,    juce::Colours::transparentBlack);
        setColour (juce::Slider::textBoxBackgroundColourId, Cols::panelInner);
        setColour (juce::Label::textColourId,               Cols::textDim);
    }

    void drawRotarySlider (juce::Graphics& g, int x, int y, int w, int h,
                           float sliderPos, float startAng, float endAng,
                           juce::Slider& slider) override
    {
        const float radius = (float) juce::jmin (w, h) * 0.5f - 4.0f;
        const float cx = (float) x + (float) w * 0.5f;
        const float cy = (float) y + (float) h * 0.5f;
        const float angle = startAng + sliderPos * (endAng - startAng);
        auto accent = slider.findColour (juce::Slider::thumbColourId);
        float hpi = juce::MathConstants<float>::halfPi;

        for (int i = 0; i < 11; ++i)
        {
            float t = (float) i / 10.0f;
            float ta = startAng + t * (endAng - startAng);
            float r1 = radius + 2.0f, r2 = radius + 6.0f;
            g.setColour ((t <= sliderPos + 0.01f) ? accent.withAlpha (0.5f) : Cols::panelBorder);
            g.drawLine (cx + r1 * std::cos (ta - hpi), cy + r1 * std::sin (ta - hpi),
                        cx + r2 * std::cos (ta - hpi), cy + r2 * std::sin (ta - hpi), 1.5f);
        }
        juce::ColourGradient bg (juce::Colour (0xff2a3040), cx - radius*0.3f, cy - radius*0.3f,
                                  juce::Colour (0xff10141c), cx + radius*0.3f, cy + radius*0.3f, true);
        g.setGradientFill (bg);
        g.fillEllipse (cx - radius, cy - radius, radius * 2, radius * 2);
        g.setColour (juce::Colour (0xff1a2030));
        g.drawEllipse (cx - radius, cy - radius, radius * 2, radius * 2, 1.5f);

        float ll = radius - 7.0f;
        g.setColour (accent);
        g.drawLine (cx, cy, cx + ll * std::cos (angle - hpi), cy + ll * std::sin (angle - hpi), 2.5f);
        g.setColour (juce::Colour (0xff1a1f2a));
        g.fillEllipse (cx - 3, cy - 3, 6, 6);
    }

    juce::Label* createSliderTextBox (juce::Slider& slider) override
    {
        auto* l = LookAndFeel_V4::createSliderTextBox (slider);
        l->setFont (juce::FontOptions (10.0f));
        return l;
    }
};

class SpectrumComponent : public juce::Component, public juce::Timer
{
public:
    SpectrumComponent (PS3100ResonatorProcessor& p) : proc (p), fft (p.fftOrder) { startTimerHz (30); }
    void timerCallback() override
    {
        if (proc.nextFFTBlockReady)
        {
            fft.performFrequencyOnlyForwardTransform (proc.fftData.data());
            proc.nextFFTBlockReady = false;
            for (int i = 0; i < 256; ++i)
            {
                float freq = 20.0f * std::pow (1000.0f, (float) i / 256.0f);
                int bin = juce::jlimit (0, proc.fftSize / 2 - 1,
                    (int)(freq / (proc.currentSampleRate / (float) proc.fftSize)));
                float db = juce::jlimit (-80.f, 0.f,
                    juce::Decibels::gainToDecibels (proc.fftData[(size_t) bin] / (float) proc.fftSize));
                scope[(size_t) i] = scope[(size_t) i] * 0.7f + ((db + 80.f) / 80.f) * 0.3f;
            }
            repaint();
        }
    }
    void paint (juce::Graphics& g) override
    {
        auto b = getLocalBounds().toFloat();
        g.setColour (Cols::panelInner); g.fillRoundedRectangle (b, 6.f);
        g.setColour (Cols::panelBorder); g.drawRoundedRectangle (b, 6.f, 1.f);
        float gf[] = { 50,100,200,500,1000,2000,5000,10000 };
        for (float f : gf) {
            float x = fToX(f,b);
            g.setColour(juce::Colour(0xff1a2030)); g.drawLine(x,b.getY(),x,b.getBottom(),0.5f);
            g.setFont(juce::FontOptions(7.f)); g.setColour(juce::Colour(0xff2a3045));
            g.drawText(f>=1000?juce::String(f/1000,0)+"k":juce::String((int)f),(int)x+2,(int)b.getBottom()-12,30,10,juce::Justification::left);
        }
        auto mk=[&](const char* pid,juce::Colour c){
            float x=fToX(proc.apvts.getRawParameterValue(pid)->load(),b);
            g.setColour(c.withAlpha(0.3f));
            for(float yy=b.getY();yy<b.getBottom();yy+=6)g.drawLine(x,yy,x,juce::jmin(yy+3,b.getBottom()),1.f);
        };
        mk(PS3100ResonatorProcessor::PARAM_BAND1_FREQ,Cols::fawn);
        mk(PS3100ResonatorProcessor::PARAM_BAND2_FREQ,Cols::periwinkle);
        mk(PS3100ResonatorProcessor::PARAM_BAND3_FREQ,Cols::teal);
        juce::Path path;
        for(int i=0;i<256;++i){
            float x=b.getX()+(float)i/256.f*b.getWidth();
            float y=b.getBottom()-scope[(size_t)i]*b.getHeight()*0.9f;
            if(i==0)path.startNewSubPath(x,y);else path.lineTo(x,y);
        }
        juce::Path fp(path);fp.lineTo(b.getRight(),b.getBottom());fp.lineTo(b.getX(),b.getBottom());fp.closeSubPath();
        g.setGradientFill(juce::ColourGradient(Cols::periwinkle.withAlpha(0.3f),0,b.getY(),Cols::indigo.withAlpha(0.05f),0,b.getBottom(),false));
        g.fillPath(fp);g.setColour(Cols::periwinkle.withAlpha(0.6f));g.strokePath(path,juce::PathStrokeType(1.5f));
    }
private:
    PS3100ResonatorProcessor& proc; juce::dsp::FFT fft; std::array<float,256> scope{};
    float fToX(float freq,juce::Rectangle<float> b)const{return b.getX()+std::log(freq/20.f)/std::log(1000.f)*b.getWidth();}
};

struct KnobWithLabel
{
    juce::Slider slider;
    juce::Label  label;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> att;

    void init (juce::Component& p, juce::AudioProcessorValueTreeState& a,
               const juce::String& pid, const juce::String& name, juce::Colour c,
               PS3100LookAndFeel& lnf)
    {
        slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 56, 14);
        slider.setColour (juce::Slider::thumbColourId, c);
        slider.setColour (juce::Slider::rotarySliderFillColourId, c);
        slider.setLookAndFeel (&lnf);
        p.addAndMakeVisible (slider);

        label.setText (name, juce::dontSendNotification);
        label.setFont (juce::FontOptions (7.5f));
        label.setColour (juce::Label::textColourId, Cols::textDim);
        label.setJustificationType (juce::Justification::centred);
        p.addAndMakeVisible (label);

        att = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (a, pid, slider);
    }

    // Place: label on top, slider below. Total height = 11 + sz + 18
    void place (int x, int y, int sz)
    {
        int cellW = sz + 14;
        label.setBounds  (x, y, cellW, 11);
        slider.setBounds (x, y + 11, cellW, sz + 18);
    }
};

class PS3100ResonatorEditor : public juce::AudioProcessorEditor
{
public:
    explicit PS3100ResonatorEditor (PS3100ResonatorProcessor& p)
        : AudioProcessorEditor (p), proc (p), spectrum (p)
    {
        setSize (740, 600);
        addAndMakeVisible (spectrum);

        volIn   .init (*this, p.apvts, p.PARAM_INPUT_GAIN,  "VOL IN",    Cols::ash,        lnf);
        lfoRate .init (*this, p.apvts, p.PARAM_LFO_RATE,    "LFO RATE",  Cols::taupe,      lnf);
        lfoDepth.init (*this, p.apvts, p.PARAM_LFO_DEPTH,   "LFO DEPTH", Cols::taupe,      lnf);
        mix     .init (*this, p.apvts, p.PARAM_MIX,         "MIX",       Cols::periwinkle, lnf);
        volOut  .init (*this, p.apvts, p.PARAM_OUTPUT_GAIN,  "VOL OUT",   Cols::ash,        lnf);

        b1Freq.init (*this, p.apvts, p.PARAM_BAND1_FREQ,   "FREQ", Cols::fawn, lnf);
        b1Emph.init (*this, p.apvts, p.PARAM_BAND1_EMPH,   "EMPH", Cols::fawn, lnf);
        b1Gain.init (*this, p.apvts, p.PARAM_BAND1_GAIN,   "GAIN", Cols::fawn, lnf);
        b1Dust.init (*this, p.apvts, p.PARAM_BAND1_EXCITE, "DUST", Cols::dust, lnf);

        b2Freq.init (*this, p.apvts, p.PARAM_BAND2_FREQ,   "FREQ", Cols::periwinkle, lnf);
        b2Emph.init (*this, p.apvts, p.PARAM_BAND2_EMPH,   "EMPH", Cols::periwinkle, lnf);
        b2Gain.init (*this, p.apvts, p.PARAM_BAND2_GAIN,   "GAIN", Cols::periwinkle, lnf);
        b2Dust.init (*this, p.apvts, p.PARAM_BAND2_EXCITE, "DUST", Cols::dust, lnf);

        b3Freq.init (*this, p.apvts, p.PARAM_BAND3_FREQ,   "FREQ", Cols::teal, lnf);
        b3Emph.init (*this, p.apvts, p.PARAM_BAND3_EMPH,   "EMPH", Cols::teal, lnf);
        b3Gain.init (*this, p.apvts, p.PARAM_BAND3_GAIN,   "GAIN", Cols::teal, lnf);
        b3Dust.init (*this, p.apvts, p.PARAM_BAND3_EXCITE, "DUST", Cols::dust, lnf);
    }

    ~PS3100ResonatorEditor() override { setLookAndFeel (nullptr); }

    void paint (juce::Graphics& g) override
    {
        g.fillAll (Cols::bg);
        auto area = getLocalBounds().reduced (10);
        g.setColour (Cols::panel); g.fillRoundedRectangle (area.toFloat(), 10.f);
        g.setColour (Cols::panelBorder); g.drawRoundedRectangle (area.toFloat(), 10.f, 1.f);

        g.setColour (Cols::taupe); g.setFont (juce::FontOptions (9.f));
        g.drawText ("KORG PS3100", 24, 18, 200, 14, juce::Justification::left);
        g.setColour (Cols::periwinkle); g.setFont (juce::FontOptions (22.f));
        g.drawText ("RESONATOR", 24, 32, 300, 28, juce::Justification::left);
        g.setColour (Cols::textDim); g.setFont (juce::FontOptions (7.f));
        g.drawText ("THREE-BAND PARALLEL STATE-VARIABLE FILTER", 24, 58, 500, 10, juce::Justification::left);

        // Band panels
        juce::Colour bc[] = { Cols::fawn, Cols::periwinkle, Cols::teal };
        const char* bn[] = { "BAND I", "BAND II", "BAND III" };
        const char* rng[] = { "60 - 600 Hz", "200 - 3k Hz", "1k - 12k Hz" };

        for (int i = 0; i < 3; ++i)
        {
            auto r = getBandRect (i);
            g.setColour (Cols::panel); g.fillRoundedRectangle (r, 8.f);
            g.setColour (Cols::panelBorder); g.drawRoundedRectangle (r, 8.f, 1.f);

            int bx = (int) r.getX();
            int by = (int) r.getY();
            int bw = (int) r.getWidth();
            int bh = (int) r.getHeight();

            g.setColour (bc[i]); g.fillEllipse ((float) bx + 14, (float) by + 12, 6, 6);
            g.setFont (juce::FontOptions (11.f));
            g.drawText (bn[i], bx + 26, by + 8, 120, 16, juce::Justification::left);

            g.setColour (Cols::textDim); g.setFont (juce::FontOptions (7.f));
            g.drawText (rng[i], bx, by + bh - 18, bw, 12, juce::Justification::centred);
        }

        g.setColour (Cols::textDim); g.setFont (juce::FontOptions (7.f));
        g.drawText ("SVF BP  \xe2\x80\xa2  VACTROL CV  \xe2\x80\xa2  OTA CLIP  \xe2\x80\xa2  DUST EXCITER",
                     20, getHeight() - 22, 400, 14, juce::Justification::left);
        g.drawText ("PS3100 / FONITRONIK v3", getWidth() - 220, getHeight() - 22, 200, 14, juce::Justification::right);
    }

    void resized() override
    {
        spectrum.setBounds (20, 74, getWidth() - 40, 130);

        // Global knobs
        const int gy = 214, ks = 50, gap = 6;
        volIn   .place (24,              gy, ks);
        lfoRate .place (24 + (ks+gap+14),   gy, ks);
        lfoDepth.place (24 + (ks+gap+14)*2, gy, ks);

        int rx = getWidth() - 24 - (ks + gap + 14) * 2;
        mix   .place (rx,                gy, ks);
        volOut.place (rx + ks + gap + 14, gy, ks);

        // Band knobs: 2×2 grid
        const int bks = 54;            // knob size
        const int cellW = bks + 14;    // cell width (knob + label padding)
        const int cellH = bks + 29 + 4; // label(11) + slider(bks+18) + gap(4)

        for (int i = 0; i < 3; ++i)
        {
            auto r = getBandRect (i);
            int bx = (int) r.getX();
            int bw = (int) r.getWidth();
            int by = (int) r.getY();

            // Center 2 columns within the band panel
            int gridW = cellW * 2 + 8;
            int startX = bx + (bw - gridW) / 2;
            int row1Y = by + 30;
            int row2Y = row1Y + cellH;

            KnobWithLabel* knobs[3][4] = {
                { &b1Freq, &b1Emph, &b1Gain, &b1Dust },
                { &b2Freq, &b2Emph, &b2Gain, &b2Dust },
                { &b3Freq, &b3Emph, &b3Gain, &b3Dust },
            };

            knobs[i][0]->place (startX,              row1Y, bks);  // FREQ
            knobs[i][1]->place (startX + cellW + 8,  row1Y, bks);  // EMPH
            knobs[i][2]->place (startX,              row2Y, bks);  // GAIN
            knobs[i][3]->place (startX + cellW + 8,  row2Y, bks);  // DUST
        }
    }

private:
    PS3100ResonatorProcessor& proc;
    PS3100LookAndFeel lnf;
    SpectrumComponent spectrum;

    KnobWithLabel volIn, lfoRate, lfoDepth, mix, volOut;
    KnobWithLabel b1Freq, b1Emph, b1Gain, b1Dust;
    KnobWithLabel b2Freq, b2Emph, b2Gain, b2Dust;
    KnobWithLabel b3Freq, b3Emph, b3Gain, b3Dust;

    // Band panel geometry — consistent between paint() and resized()
    juce::Rectangle<float> getBandRect (int idx) const
    {
        const int bandW = 228;
        const int bandH = 230;
        const int bandY = 300;
        const int totalW = bandW * 3 + 8 * 2;
        const int startX = (getWidth() - totalW) / 2;
        return juce::Rectangle<float> (
            (float)(startX + idx * (bandW + 8)),
            (float) bandY, (float) bandW, (float) bandH);
    }

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (PS3100ResonatorEditor)
};
