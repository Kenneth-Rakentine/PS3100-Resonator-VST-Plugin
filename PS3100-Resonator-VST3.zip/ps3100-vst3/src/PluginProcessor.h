#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include "DSP.h"

class PS3100ResonatorProcessor : public juce::AudioProcessor
{
public:
    PS3100ResonatorProcessor();
    ~PS3100ResonatorProcessor() override = default;

    // ── AudioProcessor overrides ──
    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "PS3100 Resonator"; }
    bool acceptsMidi()  const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    // ── Parameter tree ──
    juce::AudioProcessorValueTreeState apvts;

    // Parameter IDs
    static constexpr const char* PARAM_BAND1_FREQ = "band1Freq";
    static constexpr const char* PARAM_BAND1_EMPH = "band1Emph";
    static constexpr const char* PARAM_BAND1_GAIN = "band1Gain";
    static constexpr const char* PARAM_BAND2_FREQ = "band2Freq";
    static constexpr const char* PARAM_BAND2_EMPH = "band2Emph";
    static constexpr const char* PARAM_BAND2_GAIN = "band2Gain";
    static constexpr const char* PARAM_BAND3_FREQ = "band3Freq";
    static constexpr const char* PARAM_BAND3_EMPH = "band3Emph";
    static constexpr const char* PARAM_BAND3_GAIN = "band3Gain";
    static constexpr const char* PARAM_FEEDBACK   = "feedback";
    static constexpr const char* PARAM_MIX        = "mix";
    static constexpr const char* PARAM_LFO_RATE   = "lfoRate";
    static constexpr const char* PARAM_LFO_DEPTH  = "lfoDepth";
    static constexpr const char* PARAM_INPUT_GAIN  = "inputGain";
    static constexpr const char* PARAM_OUTPUT_GAIN = "outputGain";

private:
    juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    // Per-channel resonator engines (stereo)
    ps3100::Resonator resonatorL, resonatorR;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (PS3100ResonatorProcessor)
};
