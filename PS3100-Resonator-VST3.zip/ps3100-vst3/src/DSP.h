#pragma once
#include <cmath>
#include <algorithm>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

namespace ps3100
{

struct SVFBandpass
{
    double low = 0.0, band = 0.0, high = 0.0;
    void reset() { low = band = high = 0.0; }

    double process (double input, double freq, double q, double sampleRate)
    {
        const double f = 2.0 * std::sin (M_PI * std::min (freq, sampleRate * 0.45) / sampleRate);
        const double qInv = 1.0 / std::max (q, 0.5);
        for (int i = 0; i < 2; ++i)
        {
            low  += f * band;
            high  = input - low - qInv * band;
            band += f * high;
        }
        return band;
    }
};

struct Vactrol
{
    double state = 0.0, attackCoeff = 0.0, releaseCoeff = 0.0;
    void prepare (double sr)
    {
        attackCoeff  = 1.0 - std::exp (-1.0 / (0.005 * sr));
        releaseCoeff = 1.0 - std::exp (-1.0 / (0.050 * sr));
        state = 0.0;
    }
    double process (double target)
    {
        state += ((target > state) ? attackCoeff : releaseCoeff) * (target - state);
        return state;
    }
};

inline double transistorSoftClip (double x)
{
    const double xg = x * 1.8;
    return std::tanh (xg * 0.9) + 0.05 * std::tanh (xg * 3.0);
}

struct DCBlocker
{
    double x1 = 0.0, y1 = 0.0;
    double process (double x) { y1 = x - x1 + 0.9995 * y1; x1 = x; return y1; }
    void reset() { x1 = y1 = 0.0; }
};

struct Smoother
{
    double target = 0.0, current = 0.0, coeff = 0.0;
    void prepare (double sr, double ms = 20.0)
    {
        coeff = 1.0 - std::exp (-1.0 / (ms * 0.001 * sr));
        current = target;
    }
    void setTarget (double t) { target = t; }
    double next() { current += coeff * (target - current); return current; }
};

// ═════════════════════════════════════════════════════════════
// DUST EXCITER — Sample-and-Hold Gain Modulator
//
// This recreates the VOL IN knob artifact exactly. The artifact
// occurs because abrupt gain changes create step discontinuities
// in the signal — each step is a wideband impulse that excites
// all the resonant filters simultaneously.
//
// The Dust Exciter deliberately creates these gain steps by:
// 1. Sampling the input signal's envelope at irregular intervals
// 2. Using that sampled value as a gain multiplier until the
//    next sample point
// 3. The transition between gain values creates the impulse
//
// DUST knob controls:
// - At 0%: no effect (gain is constant 1.0)
// - At low values: slow, sparse gain steps → subtle hollow pings
// - At high values: rapid dense steps → dusty, granular texture
//
// The grain rate scales from ~5 Hz to ~2000 Hz.
// Each grain's amplitude follows the input envelope, so louder
// audio creates stronger excitation (velocity sensitive).
// ═════════════════════════════════════════════════════════════

struct DustExciter
{
    double heldGain = 1.0;       // current sample-and-hold gain value
    double prevOutput = 0.0;     // for detecting the step discontinuity
    double counter = 0.0;        // counts down to next grain
    double grainInterval = 1000; // samples between grain triggers
    double envelope = 0.0;       // input envelope follower
    double envCoeffA = 0.0;      // attack
    double envCoeffR = 0.0;      // release
    double sampleRate = 44100.0;

    // Simple LCG random
    uint32_t rng = 48271;
    double nextRand()
    {
        rng = rng * 1664525u + 1013904223u;
        return (double)(rng & 0xFFFFFF) / (double)0xFFFFFF;
    }

    void prepare (double sr)
    {
        sampleRate = sr;
        heldGain = 1.0;
        prevOutput = 0.0;
        counter = 0.0;
        envelope = 0.0;
        // Envelope: fast attack, medium release
        envCoeffA = 1.0 - std::exp (-1.0 / (0.001 * sr));  // 1ms
        envCoeffR = 1.0 - std::exp (-1.0 / (0.030 * sr));  // 30ms
    }

    // Process: takes the input signal + dust amount (0-1),
    // returns the modified signal with gain discontinuities
    double process (double input, double amount)
    {
        if (amount < 0.001)
            return input;  // bypass: no dust

        // Track input envelope
        double absIn = std::abs (input);
        double ec = (absIn > envelope) ? envCoeffA : envCoeffR;
        envelope += ec * (absIn - envelope);

        // Grain rate: 5 Hz (sparse) to 2000 Hz (dense) based on amount
        // Use exponential scaling for musical feel
        double rateHz = 5.0 * std::pow (400.0, amount);
        grainInterval = sampleRate / rateHz;

        // Count down to next grain
        counter -= 1.0;
        if (counter <= 0.0)
        {
            // Trigger a new grain: sample a new gain value
            // The gain varies around 1.0, modulated by the envelope
            // Larger envelope = bigger gain jumps = louder pings
            double variation = (nextRand() * 2.0 - 1.0) * envelope * amount * 8.0;
            heldGain = 1.0 + variation;

            // Clamp to prevent silence or extreme boost
            heldGain = std::clamp (heldGain, 0.1, 3.0);

            // Next grain interval with some jitter for organic feel
            counter = grainInterval * (0.5 + nextRand());
        }

        // Apply the held gain — the STEP between old and new gain
        // values at each grain trigger IS the excitation impulse
        return input * heldGain;
    }
};

// ─── Resonator Band ──────────────────────────────────────────
struct ResonatorBand
{
    SVFBandpass  filter;
    Vactrol      vactrol;
    Smoother     freqSmooth, emphSmooth, gainSmooth, exciteSmooth;
    DustExciter  dust;

    void prepare (double sr)
    {
        filter.reset();
        vactrol.prepare (sr);
        freqSmooth.prepare (sr, 15.0);
        emphSmooth.prepare (sr, 15.0);
        gainSmooth.prepare (sr, 15.0);
        exciteSmooth.prepare (sr, 20.0);
        dust.prepare (sr);
    }

    double process (double input, double sr, double lfoMod = 1.0)
    {
        const double freq = freqSmooth.next() * lfoMod;
        const double emph = emphSmooth.next();
        const double gain = gainSmooth.next();
        const double dustAmt = exciteSmooth.next();

        const double smoothedFreq = vactrol.process (
            std::clamp (freq, 20.0, sr * 0.45));

        // Apply dust: creates gain discontinuities in the signal
        // BEFORE it enters the bandpass filter. Each step excites
        // the filter at its resonant frequency.
        double filterIn = dust.process (input, dustAmt);

        return filter.process (filterIn, smoothedFreq, emph, sr) * gain;
    }
};

// ─── Full Resonator Engine ───────────────────────────────────
struct Resonator
{
    static constexpr int NumBands = 3;
    ResonatorBand bands[NumBands];
    DCBlocker     dcBlocker;
    Smoother      mixSmooth, lfoRateSmooth, lfoDepthSmooth;
    double        lfoPhase = 0.0;
    double        sampleRate = 44100.0;

    void prepare (double sr)
    {
        sampleRate = sr;
        lfoPhase = 0.0;
        dcBlocker.reset();
        mixSmooth.prepare (sr, 20.0);
        lfoRateSmooth.prepare (sr, 50.0);
        lfoDepthSmooth.prepare (sr, 30.0);
        for (auto& b : bands) b.prepare (sr);
    }

    double process (double input)
    {
        const double rate  = lfoRateSmooth.next();
        const double depth = lfoDepthSmooth.next();
        lfoPhase += rate / sampleRate;
        if (lfoPhase > 1.0) lfoPhase -= 1.0;
        const double lfo = (lfoPhase < 0.5)
            ? (lfoPhase * 4.0 - 1.0) : (3.0 - lfoPhase * 4.0);
        const double lfoMod = 1.0 + lfo * depth * 0.5;

        double x = transistorSoftClip (input);

        double wet = 0.0;
        for (auto& b : bands)
            wet += b.process (x, sampleRate, lfoMod);

        wet = transistorSoftClip (wet * 0.7);
        wet = dcBlocker.process (wet);

        const double mixAmt = mixSmooth.next();
        return input * (1.0 - mixAmt) + wet * mixAmt;
    }
};

} // namespace ps3100
