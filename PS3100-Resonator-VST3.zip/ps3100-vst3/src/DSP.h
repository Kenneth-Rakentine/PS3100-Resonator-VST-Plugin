#pragma once
#include <cmath>
#include <algorithm>

// ═══════════════════════════════════════════════════════════════
// PS3100 Resonator DSP — Accurate Circuit Model
//
// Based on the Korg PS3100 resonator schematic (Matthias Herrmann /
// Fonitronik v3). Three parallel state-variable bandpass filters
// with OTA-style frequency control, vactrol CV smoothing,
// BC550c/BC560c transistor-pair soft clipping, and a feedback path.
// ═══════════════════════════════════════════════════════════════

namespace ps3100
{

// ─── Chamberlin State-Variable Filter (Bandpass Mode) ────────
// Models the OTA + integrator topology of the PS3100 filter stages.
// The OTA transconductance maps to the 'f' coefficient.
struct SVFBandpass
{
    double low  = 0.0;
    double band = 0.0;
    double high = 0.0;

    void reset() { low = band = high = 0.0; }

    // Returns bandpass output. freq in Hz, q is resonance (0.5–40+)
    double process (double input, double freq, double q, double sampleRate)
    {
        // Coefficient: maps OTA transconductance to cutoff
        const double f = 2.0 * std::sin (juce::MathConstants<double>::pi
                         * std::min (freq, sampleRate * 0.45) / sampleRate);
        const double qInv = 1.0 / std::max (q, 0.5);

        // 2× oversampling for stability at high emphasis / high freq
        for (int i = 0; i < 2; ++i)
        {
            low  += f * band;
            high  = input - low - qInv * band;
            band += f * high;
        }
        return band;
    }
};

// ─── Vactrol CV Smoother (VTL5C3/2 Model) ───────────────────
// Asymmetric slew: fast attack (~5 ms), slow release (~50 ms)
// from the phosphor persistence of the LED/LDR coupling.
struct Vactrol
{
    double state = 0.0;
    double attackCoeff  = 0.0;
    double releaseCoeff = 0.0;

    void prepare (double sampleRate)
    {
        attackCoeff  = 1.0 - std::exp (-1.0 / (0.005 * sampleRate));
        releaseCoeff = 1.0 - std::exp (-1.0 / (0.050 * sampleRate));
        state = 0.0;
    }

    double process (double target)
    {
        const double coeff = (target > state) ? attackCoeff : releaseCoeff;
        state += coeff * (target - state);
        return state;
    }
};

// ─── Transistor Soft Clip (BC550c/BC560c pair) ───────────────
// Emitter-coupled pair transfer characteristic: tanh-like with
// slight asymmetry from transistor mismatch (odd harmonics).
inline double transistorSoftClip (double x)
{
    const double xg = x * 1.8;
    return std::tanh (xg * 0.9) + 0.05 * std::tanh (xg * 3.0);
}

// ─── DC Blocker ──────────────────────────────────────────────
// Prevents DC offset build-up in the feedback path.
struct DCBlocker
{
    double x1 = 0.0, y1 = 0.0;
    static constexpr double R = 0.9995;

    double process (double x)
    {
        y1 = x - x1 + R * y1;
        x1 = x;
        return y1;
    }

    void reset() { x1 = y1 = 0.0; }
};

// ─── One-Pole Smoother for Parameters ────────────────────────
struct Smoother
{
    double target = 0.0;
    double current = 0.0;
    double coeff = 0.0;

    void prepare (double sampleRate, double timeMs = 20.0)
    {
        coeff = 1.0 - std::exp (-1.0 / (timeMs * 0.001 * sampleRate));
        current = target;
    }

    void setTarget (double t) { target = t; }

    double next()
    {
        current += coeff * (target - current);
        return current;
    }
};

// ─── PS3100 Resonator Band ──────────────────────────────────
struct ResonatorBand
{
    SVFBandpass filter;
    Vactrol     vactrol;
    Smoother    freqSmooth;
    Smoother    emphSmooth;
    Smoother    gainSmooth;

    void prepare (double sampleRate)
    {
        filter.reset();
        vactrol.prepare (sampleRate);
        freqSmooth.prepare (sampleRate, 15.0);
        emphSmooth.prepare (sampleRate, 15.0);
        gainSmooth.prepare (sampleRate, 15.0);
    }

    double process (double input, double sampleRate, double lfoMod = 1.0)
    {
        const double freq = freqSmooth.next() * lfoMod;
        const double emph = emphSmooth.next();
        const double gain = gainSmooth.next();

        // Vactrol-smoothed frequency (mimics LED/LDR lag)
        const double smoothedFreq = vactrol.process (
            std::clamp (freq, 20.0, sampleRate * 0.45));

        const double bp = filter.process (input, smoothedFreq, emph, sampleRate);
        return bp * gain;
    }
};

// ─── Full PS3100 Resonator Engine ───────────────────────────
struct Resonator
{
    static constexpr int NumBands = 3;

    ResonatorBand bands[NumBands];
    DCBlocker     dcBlocker;
    Smoother      feedbackSmooth;
    Smoother      mixSmooth;
    Smoother      lfoRateSmooth;
    Smoother      lfoDepthSmooth;

    double feedbackSample = 0.0;
    double lfoPhase       = 0.0;
    double sampleRate     = 44100.0;

    void prepare (double sr)
    {
        sampleRate = sr;
        feedbackSample = 0.0;
        lfoPhase = 0.0;
        dcBlocker.reset();
        feedbackSmooth.prepare (sr, 30.0);
        mixSmooth.prepare (sr, 20.0);
        lfoRateSmooth.prepare (sr, 50.0);
        lfoDepthSmooth.prepare (sr, 30.0);

        for (auto& b : bands)
            b.prepare (sr);
    }

    // Process a single sample. Call per-sample in processBlock.
    double process (double input)
    {
        // ── LFO (triangle, like PS3100 built-in) ──
        const double rate  = lfoRateSmooth.next();
        const double depth = lfoDepthSmooth.next();
        lfoPhase += rate / sampleRate;
        if (lfoPhase > 1.0) lfoPhase -= 1.0;
        const double lfo = (lfoPhase < 0.5)
            ? (lfoPhase * 4.0 - 1.0)
            : (3.0 - lfoPhase * 4.0);
        const double lfoMod = 1.0 + lfo * depth * 0.5;

        // ── Feedback injection ──
        const double fb = feedbackSmooth.next();
        double x = input + feedbackSample * fb * 0.6;
        x = transistorSoftClip (x);   // Input stage clipping

        // ── Three parallel bandpass filters ──
        double wet = 0.0;
        for (auto& b : bands)
            wet += b.process (x, sampleRate, lfoMod);

        // ── Summing-stage soft clip (transistor pair) ──
        wet = transistorSoftClip (wet * 0.7);

        // ── DC blocking on feedback ──
        feedbackSample = dcBlocker.process (wet);

        // ── Wet/dry mix ──
        const double mixAmt = mixSmooth.next();
        return input * (1.0 - mixAmt) + wet * mixAmt;
    }
};

} // namespace ps3100
