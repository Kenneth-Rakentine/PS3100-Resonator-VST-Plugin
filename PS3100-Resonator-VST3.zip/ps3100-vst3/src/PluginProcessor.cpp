#include "PluginProcessor.h"
#include "PluginEditor.h"

juce::AudioProcessorValueTreeState::ParameterLayout
PS3100ResonatorProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    auto freqRange = [] (float lo, float hi) {
        return juce::NormalisableRange<float> (lo, hi,
            [] (float lo_, float hi_, float n) { return lo_ * std::pow (hi_ / lo_, n); },
            [] (float lo_, float hi_, float v) { return std::log (v / lo_) / std::log (hi_ / lo_); });
    };
    auto freqLabel = [] (float v, int) {
        return v >= 1000 ? juce::String (v / 1000, 1) + " kHz" : juce::String ((int) v) + " Hz";
    };

    // Band I
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND1_FREQ, 1 }, "Band I Freq",
        freqRange (60.f, 600.f), 180.f, juce::String(), juce::AudioProcessorParameter::genericParameter, freqLabel));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND1_EMPH, 1 }, "Band I Emph",
        juce::NormalisableRange<float> (0.5f, 40.f, 0.1f, 0.4f), 4.f));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND1_GAIN, 1 }, "Band I Gain",
        juce::NormalisableRange<float> (-60.f, 12.f, 0.1f), 0.f, "dB"));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND1_EXCITE, 1 }, "Band I Excite",
        juce::NormalisableRange<float> (0.f, 100.f, 0.1f), 0.f, "%"));

    // Band II
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND2_FREQ, 1 }, "Band II Freq",
        freqRange (200.f, 3000.f), 800.f, juce::String(), juce::AudioProcessorParameter::genericParameter, freqLabel));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND2_EMPH, 1 }, "Band II Emph",
        juce::NormalisableRange<float> (0.5f, 40.f, 0.1f, 0.4f), 4.f));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND2_GAIN, 1 }, "Band II Gain",
        juce::NormalisableRange<float> (-60.f, 12.f, 0.1f), 0.f, "dB"));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND2_EXCITE, 1 }, "Band II Excite",
        juce::NormalisableRange<float> (0.f, 100.f, 0.1f), 0.f, "%"));

    // Band III
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND3_FREQ, 1 }, "Band III Freq",
        freqRange (1000.f, 12000.f), 4000.f, juce::String(), juce::AudioProcessorParameter::genericParameter, freqLabel));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND3_EMPH, 1 }, "Band III Emph",
        juce::NormalisableRange<float> (0.5f, 40.f, 0.1f, 0.4f), 4.f));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND3_GAIN, 1 }, "Band III Gain",
        juce::NormalisableRange<float> (-60.f, 12.f, 0.1f), 0.f, "dB"));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND3_EXCITE, 1 }, "Band III Excite",
        juce::NormalisableRange<float> (0.f, 100.f, 0.1f), 0.f, "%"));

    // Global
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_MIX, 1 }, "Mix",
        juce::NormalisableRange<float> (0.f, 100.f, 0.1f), 70.f, "%"));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_LFO_RATE, 1 }, "LFO Rate",
        juce::NormalisableRange<float> (0.01f, 12.f, 0.01f, 0.35f), 0.3f, "Hz"));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_LFO_DEPTH, 1 }, "LFO Depth",
        juce::NormalisableRange<float> (0.f, 100.f, 0.1f), 0.f, "%"));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_INPUT_GAIN, 1 }, "Input Gain",
        juce::NormalisableRange<float> (-24.f, 12.f, 0.1f), 0.f, "dB"));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_OUTPUT_GAIN, 1 }, "Output Gain",
        juce::NormalisableRange<float> (-24.f, 12.f, 0.1f), 0.f, "dB"));

    return { params.begin(), params.end() };
}

PS3100ResonatorProcessor::PS3100ResonatorProcessor()
    : AudioProcessor (BusesProperties()
          .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
          .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PS3100_PARAMS", createParameterLayout())
{}

void PS3100ResonatorProcessor::prepareToPlay (double sampleRate, int)
{
    currentSampleRate = sampleRate;
    resonatorL.prepare (sampleRate);
    resonatorR.prepare (sampleRate);
    fifoIndex = 0;
    nextFFTBlockReady = false;
}

void PS3100ResonatorProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int numSamples  = buffer.getNumSamples();
    const int numChannels = buffer.getNumChannels();

    const float b1f = apvts.getRawParameterValue (PARAM_BAND1_FREQ)->load();
    const float b1e = apvts.getRawParameterValue (PARAM_BAND1_EMPH)->load();
    const float b1g = apvts.getRawParameterValue (PARAM_BAND1_GAIN)->load();
    const float b1x = apvts.getRawParameterValue (PARAM_BAND1_EXCITE)->load();
    const float b2f = apvts.getRawParameterValue (PARAM_BAND2_FREQ)->load();
    const float b2e = apvts.getRawParameterValue (PARAM_BAND2_EMPH)->load();
    const float b2g = apvts.getRawParameterValue (PARAM_BAND2_GAIN)->load();
    const float b2x = apvts.getRawParameterValue (PARAM_BAND2_EXCITE)->load();
    const float b3f = apvts.getRawParameterValue (PARAM_BAND3_FREQ)->load();
    const float b3e = apvts.getRawParameterValue (PARAM_BAND3_EMPH)->load();
    const float b3g = apvts.getRawParameterValue (PARAM_BAND3_GAIN)->load();
    const float b3x = apvts.getRawParameterValue (PARAM_BAND3_EXCITE)->load();
    const float mix = apvts.getRawParameterValue (PARAM_MIX)->load();
    const float lr  = apvts.getRawParameterValue (PARAM_LFO_RATE)->load();
    const float ld  = apvts.getRawParameterValue (PARAM_LFO_DEPTH)->load();
    const float igDb = apvts.getRawParameterValue (PARAM_INPUT_GAIN)->load();
    const float ogDb = apvts.getRawParameterValue (PARAM_OUTPUT_GAIN)->load();

    const float inG  = std::pow (10.f, igDb / 20.f);
    const float outG = std::pow (10.f, ogDb / 20.f);

    auto setParams = [&] (ps3100::Resonator& res) {
        res.bands[0].freqSmooth.setTarget (b1f);
        res.bands[0].emphSmooth.setTarget (b1e);
        res.bands[0].gainSmooth.setTarget (std::pow (10.0, b1g / 20.0));
        res.bands[0].exciteSmooth.setTarget (b1x / 100.0);
        res.bands[1].freqSmooth.setTarget (b2f);
        res.bands[1].emphSmooth.setTarget (b2e);
        res.bands[1].gainSmooth.setTarget (std::pow (10.0, b2g / 20.0));
        res.bands[1].exciteSmooth.setTarget (b2x / 100.0);
        res.bands[2].freqSmooth.setTarget (b3f);
        res.bands[2].emphSmooth.setTarget (b3e);
        res.bands[2].gainSmooth.setTarget (std::pow (10.0, b3g / 20.0));
        res.bands[2].exciteSmooth.setTarget (b3x / 100.0);
        res.mixSmooth.setTarget (mix / 100.0);
        res.lfoRateSmooth.setTarget (lr);
        res.lfoDepthSmooth.setTarget (ld / 100.0);
    };

    setParams (resonatorL);
    setParams (resonatorR);

    ps3100::Resonator* engines[2] = { &resonatorL, &resonatorR };

    for (int ch = 0; ch < std::min (numChannels, 2); ++ch)
    {
        float* data = buffer.getWritePointer (ch);
        auto& res = *engines[ch];
        for (int i = 0; i < numSamples; ++i)
        {
            double s = static_cast<double> (data[i]) * inG;
            s = res.process (s);
            float out = static_cast<float> (s * outG);
            data[i] = out;
            if (ch == 0) pushSampleToFifo (out);
        }
    }
    if (numChannels == 1 && buffer.getNumChannels() >= 2)
        buffer.copyFrom (1, 0, buffer, 0, 0, numSamples);
}

void PS3100ResonatorProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, destData);
}

void PS3100ResonatorProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml (getXmlFromBinary (data, sizeInBytes));
    if (xml && xml->hasTagName (apvts.state.getType()))
        apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessorEditor* PS3100ResonatorProcessor::createEditor()
{
    return new PS3100ResonatorEditor (*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new PS3100ResonatorProcessor();
}
