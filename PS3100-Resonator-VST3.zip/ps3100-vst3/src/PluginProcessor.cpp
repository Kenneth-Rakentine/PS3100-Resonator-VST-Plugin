#include "PluginProcessor.h"
#include "PluginEditor.h"

// ═══════════════════════════════════════════════════════════════
// Parameter Layout
// ═══════════════════════════════════════════════════════════════
juce::AudioProcessorValueTreeState::ParameterLayout
PS3100ResonatorProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // Helper: skewed range for frequency knobs (logarithmic feel)
    auto freqRange = [] (float lo, float hi) {
        return juce::NormalisableRange<float> (lo, hi,
            [] (float lo, float hi, float norm) {
                return lo * std::pow (hi / lo, norm);
            },
            [] (float lo, float hi, float val) {
                return std::log (val / lo) / std::log (hi / lo);
            });
    };

    // ── Band I (Low) ──
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND1_FREQ, 1 }, "Band I Freq",
        freqRange (60.0f, 600.0f), 180.0f, juce::String(),
        juce::AudioProcessorParameter::genericParameter,
        [] (float v, int) { return v >= 1000 ? juce::String (v/1000, 1) + " kHz"
                                              : juce::String ((int) v) + " Hz"; }));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND1_EMPH, 1 }, "Band I Emph",
        juce::NormalisableRange<float> (0.5f, 40.0f, 0.1f, 0.4f), 4.0f));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND1_GAIN, 1 }, "Band I Gain",
        juce::NormalisableRange<float> (-60.0f, 12.0f, 0.1f), 0.0f, "dB"));

    // ── Band II (Mid) ──
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND2_FREQ, 1 }, "Band II Freq",
        freqRange (200.0f, 3000.0f), 800.0f, juce::String(),
        juce::AudioProcessorParameter::genericParameter,
        [] (float v, int) { return v >= 1000 ? juce::String (v/1000, 1) + " kHz"
                                              : juce::String ((int) v) + " Hz"; }));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND2_EMPH, 1 }, "Band II Emph",
        juce::NormalisableRange<float> (0.5f, 40.0f, 0.1f, 0.4f), 4.0f));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND2_GAIN, 1 }, "Band II Gain",
        juce::NormalisableRange<float> (-60.0f, 12.0f, 0.1f), 0.0f, "dB"));

    // ── Band III (High) ──
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND3_FREQ, 1 }, "Band III Freq",
        freqRange (1000.0f, 12000.0f), 4000.0f, juce::String(),
        juce::AudioProcessorParameter::genericParameter,
        [] (float v, int) { return v >= 1000 ? juce::String (v/1000, 1) + " kHz"
                                              : juce::String ((int) v) + " Hz"; }));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND3_EMPH, 1 }, "Band III Emph",
        juce::NormalisableRange<float> (0.5f, 40.0f, 0.1f, 0.4f), 4.0f));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_BAND3_GAIN, 1 }, "Band III Gain",
        juce::NormalisableRange<float> (-60.0f, 12.0f, 0.1f), 0.0f, "dB"));

    // ── Global ──
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_FEEDBACK, 1 }, "Feedback",
        juce::NormalisableRange<float> (0.0f, 95.0f, 0.1f), 0.0f, "%"));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_MIX, 1 }, "Mix",
        juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), 70.0f, "%"));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_LFO_RATE, 1 }, "LFO Rate",
        juce::NormalisableRange<float> (0.01f, 12.0f, 0.01f, 0.35f), 0.3f, "Hz"));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_LFO_DEPTH, 1 }, "LFO Depth",
        juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), 0.0f, "%"));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_INPUT_GAIN, 1 }, "Input Gain",
        juce::NormalisableRange<float> (-24.0f, 12.0f, 0.1f), 0.0f, "dB"));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { PARAM_OUTPUT_GAIN, 1 }, "Output Gain",
        juce::NormalisableRange<float> (-24.0f, 12.0f, 0.1f), 0.0f, "dB"));

    return { params.begin(), params.end() };
}

// ═══════════════════════════════════════════════════════════════
// Constructor
// ═══════════════════════════════════════════════════════════════
PS3100ResonatorProcessor::PS3100ResonatorProcessor()
    : AudioProcessor (BusesProperties()
          .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
          .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PS3100_PARAMS", createParameterLayout())
{
}

// ═══════════════════════════════════════════════════════════════
// Prepare
// ═══════════════════════════════════════════════════════════════
void PS3100ResonatorProcessor::prepareToPlay (double sampleRate, int /*samplesPerBlock*/)
{
    resonatorL.prepare (sampleRate);
    resonatorR.prepare (sampleRate);
}

// ═══════════════════════════════════════════════════════════════
// Process Block — the audio heart
// ═══════════════════════════════════════════════════════════════
void PS3100ResonatorProcessor::processBlock (juce::AudioBuffer<float>& buffer,
                                              juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int numSamples  = buffer.getNumSamples();
    const int numChannels = buffer.getNumChannels();

    // ── Read all parameter values ──
    const float b1Freq = apvts.getRawParameterValue (PARAM_BAND1_FREQ)->load();
    const float b1Emph = apvts.getRawParameterValue (PARAM_BAND1_EMPH)->load();
    const float b1Gain = apvts.getRawParameterValue (PARAM_BAND1_GAIN)->load();
    const float b2Freq = apvts.getRawParameterValue (PARAM_BAND2_FREQ)->load();
    const float b2Emph = apvts.getRawParameterValue (PARAM_BAND2_EMPH)->load();
    const float b2Gain = apvts.getRawParameterValue (PARAM_BAND2_GAIN)->load();
    const float b3Freq = apvts.getRawParameterValue (PARAM_BAND3_FREQ)->load();
    const float b3Emph = apvts.getRawParameterValue (PARAM_BAND3_EMPH)->load();
    const float b3Gain = apvts.getRawParameterValue (PARAM_BAND3_GAIN)->load();
    const float fb     = apvts.getRawParameterValue (PARAM_FEEDBACK)->load();
    const float mix    = apvts.getRawParameterValue (PARAM_MIX)->load();
    const float lfoR   = apvts.getRawParameterValue (PARAM_LFO_RATE)->load();
    const float lfoD   = apvts.getRawParameterValue (PARAM_LFO_DEPTH)->load();
    const float inGdB  = apvts.getRawParameterValue (PARAM_INPUT_GAIN)->load();
    const float outGdB = apvts.getRawParameterValue (PARAM_OUTPUT_GAIN)->load();

    const float inGain  = std::pow (10.0f, inGdB  / 20.0f);
    const float outGain = std::pow (10.0f, outGdB / 20.0f);

    // Helper to push params into a Resonator engine
    auto setParams = [&] (ps3100::Resonator& res)
    {
        res.bands[0].freqSmooth.setTarget (b1Freq);
        res.bands[0].emphSmooth.setTarget (b1Emph);
        res.bands[0].gainSmooth.setTarget (std::pow (10.0, b1Gain / 20.0));
        res.bands[1].freqSmooth.setTarget (b2Freq);
        res.bands[1].emphSmooth.setTarget (b2Emph);
        res.bands[1].gainSmooth.setTarget (std::pow (10.0, b2Gain / 20.0));
        res.bands[2].freqSmooth.setTarget (b3Freq);
        res.bands[2].emphSmooth.setTarget (b3Emph);
        res.bands[2].gainSmooth.setTarget (std::pow (10.0, b3Gain / 20.0));
        res.feedbackSmooth.setTarget (fb / 100.0);
        res.mixSmooth.setTarget (mix / 100.0);
        res.lfoRateSmooth.setTarget (lfoR);
        res.lfoDepthSmooth.setTarget (lfoD / 100.0);
    };

    setParams (resonatorL);
    setParams (resonatorR);

    // ── Per-sample processing ──
    ps3100::Resonator* engines[2] = { &resonatorL, &resonatorR };

    for (int ch = 0; ch < std::min (numChannels, 2); ++ch)
    {
        float* data = buffer.getWritePointer (ch);
        auto&  res  = *engines[ch];

        for (int i = 0; i < numSamples; ++i)
        {
            double sample = static_cast<double> (data[i]) * inGain;
            sample = res.process (sample);
            data[i] = static_cast<float> (sample * outGain);
        }
    }

    // If mono input, copy L to R
    if (numChannels == 1 && buffer.getNumChannels() >= 2)
        buffer.copyFrom (1, 0, buffer, 0, 0, numSamples);
}

// ═══════════════════════════════════════════════════════════════
// State Save / Restore (preset support)
// ═══════════════════════════════════════════════════════════════
void PS3100ResonatorProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, destData);
}

void PS3100ResonatorProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml (getXmlFromBinary (data, sizeInBytes));
    if (xml && xml->hasTagName (apvts.state.getType()))
        apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

// ═══════════════════════════════════════════════════════════════
// Editor creation
// ═══════════════════════════════════════════════════════════════
juce::AudioProcessorEditor* PS3100ResonatorProcessor::createEditor()
{
    // Use JUCE's generic parameter editor for now.
    // Replace with PS3100ResonatorEditor for custom GUI.
    return new juce::GenericAudioProcessorEditor (*this);
}

// ═══════════════════════════════════════════════════════════════
// Plugin instantiation (required by JUCE)
// ═══════════════════════════════════════════════════════════════
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new PS3100ResonatorProcessor();
}
