# PS3100 Resonator — VST3 Build Guide (Windows)

## What You Need

1. **Visual Studio 2022** (Community edition is free)
   - Install with "Desktop development with C++" workload
   - https://visualstudio.microsoft.com/downloads/

2. **CMake 3.22+**
   - https://cmake.org/download/
   - Or install via: `winget install Kitware.CMake`

3. **JUCE Framework** (free for open-source / GPL, or paid for proprietary)
   - https://github.com/juce-framework/JUCE

## Step-by-Step Build

### 1. Extract this project folder somewhere, e.g.:
```
C:\dev\ps3100-vst3\
```

### 2. Get JUCE — clone it INTO the project folder:
```cmd
cd C:\dev\ps3100-vst3
git clone https://github.com/juce-framework/JUCE.git
```

This gives you:
```
ps3100-vst3/
├── JUCE/               ← JUCE framework
├── CMakeLists.txt
├── src/
│   ├── DSP.h           ← PS3100 circuit model
│   ├── PluginProcessor.h
│   ├── PluginProcessor.cpp
│   ├── PluginEditor.h
│   └── PluginEditor.cpp
├── BUILD.md            ← this file
└── README.md
```

### 3. Generate the Visual Studio project:
```cmd
cd C:\dev\ps3100-vst3
mkdir build
cd build
cmake .. -G "Visual Studio 17 2022" -A x64
```

If JUCE is somewhere else, point to it:
```cmd
cmake .. -G "Visual Studio 17 2022" -A x64 -DJUCE_DIR=C:\path\to\JUCE
```

### 4. Build the VST3:
```cmd
cmake --build . --config Release
```

Or open `build\PS3100Resonator.sln` in Visual Studio and build from there.

### 5. Find your plugin:

The built VST3 will be at:
```
build\PS3100Resonator_artefacts\Release\VST3\PS3100 Resonator.vst3
```

It will also be **auto-copied** to your system VST3 folder:
```
C:\Program Files\Common Files\VST3\PS3100 Resonator.vst3
```

### 6. Load in your DAW:

Rescan plugins in your DAW (Ableton, FL Studio, Reaper, Bitwig, etc.)
and "PS3100 Resonator" should appear under Effects.

## Parameters

| Parameter     | Range          | Default | Description                              |
|---------------|----------------|---------|------------------------------------------|
| Band I Freq   | 60–600 Hz      | 180 Hz  | Low band center frequency                |
| Band I Emph   | 0.5–40         | 4.0     | Low band resonance / Q                   |
| Band I Gain   | -60 to +12 dB  | 0 dB    | Low band level                           |
| Band II Freq  | 200–3000 Hz    | 800 Hz  | Mid band center frequency                |
| Band II Emph  | 0.5–40         | 4.0     | Mid band resonance / Q                   |
| Band II Gain  | -60 to +12 dB  | 0 dB    | Mid band level                           |
| Band III Freq | 1k–12k Hz      | 4000 Hz | High band center frequency               |
| Band III Emph | 0.5–40         | 4.0     | High band resonance / Q                  |
| Band III Gain | -60 to +12 dB  | 0 dB    | High band level                          |
| Feedback      | 0–95%          | 0%      | Output→input feedback (PS3100 style)     |
| Mix           | 0–100%         | 70%     | Wet/dry blend                            |
| LFO Rate      | 0.01–12 Hz     | 0.3 Hz  | Frequency modulation speed               |
| LFO Depth     | 0–100%         | 0%      | Frequency modulation amount              |
| Input Gain    | -24 to +12 dB  | 0 dB    | Input level                              |
| Output Gain   | -24 to +12 dB  | 0 dB    | Output level                             |

## DSP Architecture

The signal flow models the Korg PS3100 resonator circuit:

```
Input → [Input Gain] → [+ Feedback] → [Transistor Soft Clip]
                                            │
                    ┌───────────────────────┼───────────────────────┐
                    ▼                       ▼                       ▼
              [SVF Band I]           [SVF Band II]          [SVF Band III]
              [Vactrol CV]           [Vactrol CV]           [Vactrol CV]
              [Band Gain]            [Band Gain]            [Band Gain]
                    │                       │                       │
                    └───────────┬───────────┘───────────────────────┘
                                ▼
                    [Sum → Transistor Soft Clip]
                                │
                    [DC Blocker] → Feedback path
                                │
                    [Wet/Dry Mix] → [Output Gain] → Out
```

- **SVF Bandpass**: Chamberlin state-variable filter modeling OTA+integrator topology
- **Vactrol CV**: Asymmetric slew (5ms attack / 50ms release) from VTL5C3/2
- **Soft Clip**: BC550c/BC560c complementary pair transfer characteristic
- **LFO**: Triangle wave modulating all three band frequencies simultaneously

## Troubleshooting

**"JUCE not found"**: Make sure JUCE is cloned into the project folder,
or set `-DJUCE_DIR=...` when running cmake.

**Plugin doesn't appear in DAW**: Check that the .vst3 folder exists in
`C:\Program Files\Common Files\VST3\`. Rescan in your DAW.

**Crackling audio**: Increase your DAW's buffer size. The per-sample
processing with 2× oversampled SVF is CPU-intensive.
