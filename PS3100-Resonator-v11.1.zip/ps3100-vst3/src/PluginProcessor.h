#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include "DSP.h"
#include <array>

class PS3100ResonatorProcessor : public juce::AudioProcessor {
public:
    PS3100ResonatorProcessor();~PS3100ResonatorProcessor()override=default;
    void prepareToPlay(double,int)override;void releaseResources()override{}
    void processBlock(juce::AudioBuffer<float>&,juce::MidiBuffer&)override;
    juce::AudioProcessorEditor*createEditor()override;
    bool hasEditor()const override{return true;}
    const juce::String getName()const override{return"PS3100 Resonator";}
    bool acceptsMidi()const override{return false;}bool producesMidi()const override{return false;}
    bool isMidiEffect()const override{return false;}double getTailLengthSeconds()const override{return 1.0;}
    int getNumPrograms()override{return 1;}int getCurrentProgram()override{return 0;}
    void setCurrentProgram(int)override{}const juce::String getProgramName(int)override{return{};}
    void changeProgramName(int,const juce::String&)override{}
    void getStateInformation(juce::MemoryBlock&)override;void setStateInformation(const void*,int)override;

    juce::AudioProcessorValueTreeState apvts;

    static constexpr const char* PDMIX="dMix";
    static constexpr const char* PDT[8]={"dT0","dT1","dT2","dT3","dT4","dT5","dT6","dT7"};
    static constexpr const char* PDFB[8]={"dFb0","dFb1","dFb2","dFb3","dFb4","dFb5","dFb6","dFb7"};
    static constexpr const char* PFSHIFT="fShift";
    static constexpr const char* PVMIX="vMix";
    static constexpr const char* PVB[8]={"vB0","vB1","vB2","vB3","vB4","vB5","vB6","vB7"};
    static constexpr const char* PB1F="b1F";static constexpr const char* PB1E="b1E";
    static constexpr const char* PB1G="b1G";static constexpr const char* PB1D="b1D";
    static constexpr const char* PB1S="b1S";static constexpr const char* PB1C="b1C";
    static constexpr const char* PB1CF="b1CF";static constexpr const char* PB1CT="b1CT";
    static constexpr const char* PB1CR="b1CR";
    static constexpr const char* PB2F="b2F";static constexpr const char* PB2E="b2E";
    static constexpr const char* PB2G="b2G";static constexpr const char* PB2D="b2D";
    static constexpr const char* PB2S="b2S";static constexpr const char* PB2C="b2C";
    static constexpr const char* PB2CF="b2CF";static constexpr const char* PB2CT="b2CT";
    static constexpr const char* PB2CR="b2CR";
    static constexpr const char* PB3F="b3F";static constexpr const char* PB3E="b3E";
    static constexpr const char* PB3G="b3G";static constexpr const char* PB3D="b3D";
    static constexpr const char* PB3S="b3S";static constexpr const char* PB3C="b3C";
    static constexpr const char* PB3CF="b3CF";static constexpr const char* PB3CT="b3CT";
    static constexpr const char* PB3CR="b3CR";
    static constexpr const char* PMIX="mix";static constexpr const char* PLFOR="lfoR";
    static constexpr const char* PLFOD="lfoD";static constexpr const char* PIG="inG";
    static constexpr const char* POG="outG";static constexpr const char* PVERB="verb";

    static constexpr int fftOrder=11;static constexpr int fftSize=1<<fftOrder;
    std::array<float,fftSize*2>fftData{};std::array<float,fftSize>fifo{};
    int fifoIndex=0;bool nextFFTBlockReady=false;
    void pushSampleToFifo(float s)noexcept{if(fifoIndex==fftSize){if(!nextFFTBlockReady){std::copy(fifo.begin(),fifo.end(),fftData.begin());std::fill(fftData.begin()+fftSize,fftData.end(),0.f);nextFFTBlockReady=true;}fifoIndex=0;}fifo[(size_t)fifoIndex++]=s;}
    double currentSampleRate=44100;
private:
    juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    ps3100::Resonator resonatorL,resonatorR;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PS3100ResonatorProcessor)
};
